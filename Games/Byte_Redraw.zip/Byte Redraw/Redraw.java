import java.awt.image.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Redraw {

    
    public static final String[] COLORS = {
        "000000", "000023", "002a00", "003131", "380000", "3f003f", "462300", "464646", "232323", "232369", "236923", "236969", "692323", "692369", "696923", "696969", 
        "000000", "040404", "0a0a0a", "131313", "1c1c1c", "272727", "333333", "3c3c3c", "464646", "4f4f4f", "575757", "5f5f5f", "676767", "727272", "7a7a7a", "828282",
        "00003f", "14004f", "30005f", "52006e", "7e007e", "8d0069", "9c0050", "9c0028", "9c0000", "9c2800", "9c5000", "9c7400", "9c9c00", "749c00", "509c00", "289c00",
        "004a00", "005b17", "006e38", "007f5f", "009292", "007aa4", "005cb5", "002eb5", "5c5cb5", "705cb5", "875cb5", "9e5cb5", "b55cb5", "b55c9e", "b55c87", "b55c70",
        "542b2b", "694136", "7e5e40", "92804a", "a7a755", "a4bb5f", "9acf6a", "80cf6a", "6acf6a", "6acf80", "6acf9a", "6acfb5", "6acfcf", "6ab5cf", "6a9acf", "6a80cf",
        "45455f", "5d5575", "7b678d", "9a78a4", "bb88bb", "d299c5", "e8a9cb", "e8a9b8", "e8a9a9", "e8b8a9", "e8cba9", "e8d9a9", "e8e8a9", "d9e8a9", "cbe8a9", "b8e8a9",
        "4d694d", "5f8267", "729c88", "84b5aa", "97cfcf", "a9d9e8", "badfff", "bacaff", "000071", "1c0071", "390071", "550071", "710071", "710055", "710039", "71001c", 
        "2f0000", "3a0e00", "452300", "503c00", "5c5c00", "4d6700", "397100", "1c7100", "007100", "00711c", "007139", "007155", "007171", "005571", "003971", "001c71",
        "17172f", "231d3a", "342345", "452850", "5c2e5c", "673458", "713955", "713945", "713939", "714539", "715539", "716139", "717139", "617139", "557139", "457139",
        "172f17", "1d3a23", "234534", "285045", "2e5c5c", "345867", "395571", "394571", "515171", "595171", "615171", "695171", "715171", "715169", "715161", "715159",
        "2f2121", "3a2d29", "453b32", "504b39", "5c5c42", "60674a", "617151", "597151", "517151", "517159", "517161", "517169", "517171", "516971", "516171", "515971",
        "00001b", "080021", "140028", "23002e", "350035", "3b002d", "410020", "410010", "410000", "411000", "412000", "413100", "414100", "314100", "204100", "104100",
        "001b00", "002108", "002814", "002e23", "003535", "002d3b", "002041", "001041", "202041", "282041", "312041", "392041", "412041", "412039", "412031", "412028",
        "1b0d0d", "211410", "281e14", "2e2817", "35351a", "343b1d", "314120", "284120", "204120", "204128", "204131", "204139", "204141", "203941", "203141", "202841",
        "13131b", "191721", "201c28", "2b202e", "352535", "3b2937", "412d35", "412d31", "412d2d", "41312d", "41352d", "413d2d", "41412d", "3d412d", "35412d", "31412d",
        "131b13", "172119", "1c2820", "202e2b", "253535", "29373b", "2d3541", "2d3141"
    };
    public static void main(String[] args) throws IOException {
        System.out.println(COLORS.length);
        getColorList();
        int hOffset = 0, wOffset = 0;
        if(args.length == 0) {
            System.out.println("No Image Given");
            System.exit(0);
        }
        BufferedImage image = ImageIO.read(new File(args[0]));
        if(args.length == 3) {
            if(isDigit(args[1])) hOffset = Integer.parseInt(args[1]);
            if(isDigit(args[2])) wOffset = Integer.parseInt(args[2]);
        }
        writeImageData(image, hOffset, wOffset);
        JFrame app = new JFrame();
        JLabel img = new JLabel();
        app.setSize(1000, 1000);
        app.setLayout(null);
        img.setBounds(0, 0, 1000, 1000);
        BufferedImage scaled = scaleImage(image, app);
        img.setIcon(new ImageIcon(scaled));
        
        app.add(img);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    }

    public static void writeImageData(BufferedImage image, int heightOffset, int widthOffset) throws IOException {
        OutputStream outStream = new FileOutputStream("img_data.bin");

        for (int v = heightOffset; v < image.getHeight(); v++) {
            if(v-heightOffset > 200) break;
            for (int h = widthOffset; h < image.getWidth(); h++) {
                if(h-widthOffset > 320) continue;
                int actRed          = (image.getRGB(h, v)   & 0x00ff0000) >> 16,
                    actGreen        = (image.getRGB(h, v)   & 0x0000ff00) >> 8,
                    actBlue         = image.getRGB(h, v)    & 0x000000ff;
                
                double lowestDist = Integer.MAX_VALUE;
                int color = 0;
                for (int c = 0; c < COLORS.length; c++) {
                    int colorChoose = Integer.parseInt(COLORS[c], 16);
                    int currentRed      = (colorChoose  & 0x00ff0000) >> 16,
                        currentGreen    = (colorChoose  & 0x0000ff00) >> 8,
                        currentBlue     = colorChoose   & 0x000000ff;
                    double dist = Math.sqrt( Math.pow(actRed-currentRed, 2) + Math.pow(actGreen-currentGreen, 2) + Math.pow(actBlue-currentBlue, 2) );
                    if(lowestDist > dist) {
                        lowestDist = dist;
                        color = c;
                    }
                }
                image.setRGB(h, v, Integer.parseInt(COLORS[color], 16));
                outStream.write(color);
            }
            outStream.write(250);
        }
        outStream.write(251);
        outStream.close();
    }

    public static BufferedImage scaleImage(BufferedImage image, JFrame app) {
        System.out.println("\nScaling Image");
        int scale = 1,
            imageWidth = image.getWidth(), imageHeight = image.getHeight(),
            appWidth = app.getWidth(), appHeight = app.getHeight();
        System.out.println(
            "App Width: " + appWidth + "\n" + "App Height: " + appHeight + "\n" +
            "Original Width: " + imageWidth + "\n" + "Original Height " + imageHeight
        );
        BufferedImage scaledImage = image;
        if(appWidth <= imageWidth || appHeight <= imageHeight) {
            while(appWidth <= imageWidth/scale) scale++;
            while(appHeight <= imageHeight/scale) scale++;
            scaledImage = new BufferedImage(imageWidth/scale, imageHeight/scale, BufferedImage.SCALE_SMOOTH);
            scaledImage.createGraphics().drawImage(image, 0, 0, imageWidth/scale, imageHeight/scale, null);
        }
        System.out.println("Scaled by: " + scale);
        return scaledImage;
    }

    public static boolean isDigit(String text) {
        char[] digets = text.toCharArray();
        for (char diget : digets) {
            if(!Character.isDigit(diget)) return false;
        }
        return true;
    }

    public static void getColorList() throws IOException {
        BufferedImage colorArrayImage = ImageIO.read(new File("vga_palette.png"));
        for (short v = 0; v < 16; v++) {
            for (short h = 0; h < 16; h++) {
                String color_in_hex = Integer.toHexString(colorArrayImage.getRGB(h*16+1, v*16+1)).substring(2);
                System.out.print("\"" + color_in_hex + "\", ");
            }
            System.out.println();
        }
    }
}