package Tools;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import Display.Display;
import Display.ScaleDisplay;
import Display.State;

public class ColorScaleTool extends Tool {
    private JComboBox<State> red_state, green_state, blue_state;
    private JComboBox<String> swap_r, swap_g, swap_b;
    private JCheckBox average;
    private JButton reset;

    public ColorScaleTool() {
        red_state = new JComboBox<>(State.values());
        green_state = new JComboBox<>(State.values());
        blue_state = new JComboBox<>(State.values());
        swap_r = new JComboBox<>(new String[]{"Red", "Green", "Blue"});
        swap_g = new JComboBox<>(new String[]{"Red", "Green", "Blue"});
        swap_b = new JComboBox<>(new String[]{"Red", "Green", "Blue"});
        average = new JCheckBox("Average");
        reset = new JButton("Reset");

        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { reset(); }
        });

        reset();
        add(red_state);
        add(green_state);
        add(blue_state);
        add(swap_r);
        add(swap_g);
        add(swap_b);
        add(average);
        add(reset);
    }

    private void reset() {
        red_state.setSelectedItem(State.SAME);
        green_state.setSelectedItem(State.SAME);
        blue_state.setSelectedItem(State.SAME);
        swap_r.setSelectedItem("Red");
        swap_g.setSelectedItem("Green");
        swap_b.setSelectedItem("Blue");
        average.setSelected(false);
    }

    @Override
    public Display getDisplay() {
        return new ScaleDisplay(
            (State)red_state.getSelectedItem(),
            (State)green_state.getSelectedItem(),
            (State)blue_state.getSelectedItem(),
            (String) swap_r.getSelectedItem(),
            (String) swap_g.getSelectedItem(),
            (String) swap_b.getSelectedItem(),
            average.isSelected()
        );
    }

    @Override
    public String toString() { return "Color Scaling"; }
}