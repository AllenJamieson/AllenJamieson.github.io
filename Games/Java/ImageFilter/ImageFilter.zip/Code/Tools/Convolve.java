package Tools;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JTextField;

import Display.Convolution;
import Display.Display;

public class Convolve extends Tool {
    private final byte PADDING = 3;
    private JPanel kernal;

    public Convolve() {
        kernal = new JPanel(new GridLayout(3, 3, PADDING, PADDING));
        for (byte k = 0; k < 9; k++) {
            JTextField ker = new JTextField();
            ker.setPreferredSize(new Dimension(50, 20));
            kernal.add(ker);
        }
        add(kernal);
    }

    private double convertValue(String text) {
        String[] fraction = text.split("/");
        if(fraction.length > 2) return 0;
        try {
            if(fraction.length == 2) {
                double numerator = Double.parseDouble(fraction[0]);
                double denominator = Double.parseDouble(fraction[1]);
                return (denominator == 0) ? 0 : numerator/denominator;
            }
            return Double.parseDouble(text);
        } catch(NumberFormatException e) {
            System.out.println(text + " is not a number");
            return 0;
        }
    }

    @Override
    public Display getDisplay() {
        double[][] kernal_vals = new double[3][3];
        for (byte v = 0; v < 3; v++) {
            for (byte h = 0; h < 3; h++) {
                Component c = kernal.getComponent(3*v+h);
                String kern = ((JTextField)c).getText();
                kernal_vals[v][h] = convertValue(kern);
            }
        }
        return new Convolution(kernal_vals);
    }

    @Override
    public String toString() { return "Kernal Convolution"; }
}