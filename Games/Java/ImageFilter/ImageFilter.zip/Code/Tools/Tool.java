package Tools;

import javax.swing.JPanel;

import Display.Display;

public abstract class Tool extends JPanel {
    public abstract Display getDisplay();
    @Override
    public abstract String toString();
}