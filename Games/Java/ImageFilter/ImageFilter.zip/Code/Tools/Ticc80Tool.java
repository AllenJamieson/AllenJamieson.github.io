package Tools;

import Display.Display;
import Display.Tic80;

public class Ticc80Tool extends Tool {
    @Override
    public Display getDisplay() { return new Tic80(); }

    @Override
    public String toString() { return "Tic80"; }
}