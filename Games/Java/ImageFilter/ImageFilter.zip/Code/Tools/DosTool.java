package Tools;

import Display.Display;
import Display.Dos;

public class DosTool extends Tool {
    @Override
    public Display getDisplay() { return new Dos(); }

    @Override
    public String toString() { return "Dos"; }
}