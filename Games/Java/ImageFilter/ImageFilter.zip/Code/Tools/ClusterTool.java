package Tools;

import java.awt.Dimension;

import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import Display.ClusterDisplay;
import Display.Display;

public class ClusterTool extends Tool {
    private JSpinner k;

    public ClusterTool() {
        k = new JSpinner(new SpinnerNumberModel(2, 1, 999, 1));
        k.setPreferredSize(new Dimension(50, 25));
        add(k);
    }

    @Override
    public Display getDisplay() {
        return new ClusterDisplay((int)k.getValue());
    }

    @Override
    public String toString() { return "K-Clustering"; }
}