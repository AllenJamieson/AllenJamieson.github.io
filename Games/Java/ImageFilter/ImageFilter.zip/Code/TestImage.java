import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Tools.ClusterTool;
import Tools.ColorScaleTool;
import Tools.Convolve;
import Tools.DosTool;
import Tools.Ticc80Tool;
import Tools.Tool;

public class TestImage extends JFrame {

    private final byte HEADER = 75;
    private Tool[] tools = {new ColorScaleTool(), new Convolve(), new ClusterTool(), new DosTool(), new Ticc80Tool()};

    private JPanel controls;
    private JButton close, load, save, process;
    private Tool tool;
    private JComboBox<Tool> choice_box;
    private ImageProcess image_processor;

    public TestImage() {
        define();
        actions();
        
        setTitle("Image Filter");
        setLayout(null);
        setUndecorated(true);
        setSize(Toolkit.getDefaultToolkit().getScreenSize());
        controls.setBounds(0, 0, getWidth()-50, HEADER);
        close.setBounds(getWidth() - 50, 5, 45, 45);
        image_processor.setBounds(0, HEADER, getWidth(), getHeight()-HEADER);
        addControls();
        add(controls);
        add(close);
        add(image_processor);
        setVisible(true);
    }

    private void define() {
        controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        load = new JButton("Load");
        tool = tools[0];
        process = new JButton("Process");
        save = new JButton("Save");
        close = new JButton("X");
        choice_box = new JComboBox<>(tools);
        image_processor = new ImageProcess(this);
    }

    private void addControls() {
        controls.add(load);
        controls.add(choice_box);
        controls.add(tool);
        controls.add(process);
        controls.add(save);
    }

    private void actions() {
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) { System.exit(0); }
        });

        load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try { image_processor.load(); }
                catch (IOException e1) { System.out.println("Loading error"); }
            }
        });

        choice_box.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED) {
                    controls.remove(tool);
                    tool = tools[choice_box.getSelectedIndex()];
                    controls.add(tool, 2);
                    controls.revalidate();
                }
            }
        });

        process.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                image_processor.imageEdit(tool.getDisplay());
            }
        });

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try { image_processor.save(); }
                catch (IOException e) { System.out.println("Saving error"); }
            }
        });
    }
}