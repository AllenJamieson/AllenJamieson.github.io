import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import Display.ClusterDisplay;
import Display.Convolution;
import Display.Display;
import Display.Dos;
import Display.ScaleDisplay;
import Display.State;
import Display.Tic80;

public class TestImage {

    private enum Choices {
        COLOR_FILTER, CLUSTERING, CONVOLVE, DOS, TIC_80
    };

    private final byte HEADER = 75;

    private JFrame app;
    private JPanel controls;
    private JButton close, load, save, process;
    private JLabel red, green, blue, k_name;
    private JComboBox<Choices> choice_box = new JComboBox<>(Choices.values());

    private ImageProcess image_processor;
    private JSpinner k;
    private JComboBox<State> red_state, green_state, blue_state;
    private JCheckBox average;
    private JPanel kernal;

    public TestImage() {
        int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(),
            height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        define();
        app.setLayout(null);
        app.setUndecorated(true);
        app.setSize(width, height);
        
        red_state.setSelectedItem(State.SAME);
        green_state.setSelectedItem(State.SAME);
        blue_state.setSelectedItem(State.SAME);
        
        for (byte k = 0; k < 9; k++) {
            JTextField ker = new JTextField();
            ker.setPreferredSize(new Dimension(50, 20));
            kernal.add(ker);
        }

        k.setPreferredSize(new Dimension(50, 25)); // TODO BAD?

        controls.setBounds(0, 0, width, HEADER);
        image_processor.setBounds(0, HEADER, width, height-HEADER);

        actions();
        addControls();
        proecssChoice(Choices.COLOR_FILTER);

        app.add(controls);
        app.add(image_processor);
        app.setVisible(true);
    }

    private void define() {
        app = new JFrame("Image Filter");
        controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        close = new JButton("X");
        load = new JButton("Load");
        process = new JButton("Process");
        save = new JButton("Save");
        k = new JSpinner(new SpinnerNumberModel(2, 1, 999, 1));
        red_state = new JComboBox<>(State.values());
        green_state = new JComboBox<>(State.values());
        blue_state = new JComboBox<>(State.values());
        average = new JCheckBox("Average");
        red = new JLabel("Red:");
        green = new JLabel("Green:");
        blue = new JLabel("Blue:");
        k_name = new JLabel("K:");
        image_processor = new ImageProcess(app);
        kernal = new JPanel(new GridLayout(3, 3));
    }

    private void addControls() {
        controls.add(load);
        controls.add(choice_box);
        controls.add(k_name);
        controls.add(k);
        controls.add(red);
        controls.add(red_state);
        controls.add(green);
        controls.add(green_state);
        controls.add(blue);
        controls.add(blue_state);
        controls.add(average);
        controls.add(kernal);
        controls.add(process);
        controls.add(save);
        controls.add(close);
    }

    private void actions() {
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) { System.exit(0); }
        });

        load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try { image_processor.load(); }
                catch (IOException e1) { System.out.println("Loading error"); }
            }
        });

        choice_box.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED)
                    proecssChoice((Choices)choice_box.getSelectedItem());
            }
        });

        process.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Display d = null;
                switch ((Choices)choice_box.getSelectedItem()) {
                    case COLOR_FILTER:
                        d = new ScaleDisplay(
                            (State)red_state.getSelectedItem(),
                            (State)green_state.getSelectedItem(),
                            (State)blue_state.getSelectedItem(),
                            average.isSelected()
                        );
                    break;
                    case CLUSTERING:
                        d = new ClusterDisplay((int) k.getValue());
                    break;
                    case CONVOLVE:
                        double[][] kernal_vals = new double[3][3];
                        for (byte v = 0; v < 3; v++) {
                            for (byte h = 0; h < 3; h++) {
                                Component c = kernal.getComponent(3*v+h);
                                String kern = ((JTextField)c).getText();
                                kernal_vals[v][h] = convertValue(kern);
                            }
                        }
                        d = new Convolution(kernal_vals);
                    break;
                    case DOS: d = new Dos(); break;
                    case TIC_80: d = new Tic80(); break;
                }
                if(d != null) image_processor.imageEdit(d);
            }
        });

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try { image_processor.save(); }
                catch (IOException e) { System.out.println("Saving error"); }
            }
        });
    }
    
    private double convertValue(String text) {
        String[] fraction = text.split("/");
        if(fraction.length > 2) return 0;
        try {
            if(fraction.length == 2) {
                double numerator = Double.parseDouble(fraction[0]);
                double denominator = Double.parseDouble(fraction[1]);
                return (denominator == 0) ? 0 : numerator/denominator;
            }
            return Double.parseDouble(text);
        } catch(NumberFormatException e) {
            System.out.println(text + " is not a number");
            return 0;
        }
    }

    private void proecssChoice(Choices choice) {
        for (Component component : controls.getComponents()) {
            component.setVisible(false);
        }
        close.setVisible(true);
        load.setVisible(true);
        process.setVisible(true);
        choice_box.setVisible(true);
        save.setVisible(true);
        switch (choice) {
            case COLOR_FILTER:
                red_state.setVisible(true);
                green_state.setVisible(true);
                blue_state.setVisible(true);
                average.setVisible(true);
                red.setVisible(true);
                green.setVisible(true);
                blue.setVisible(true);
            break;
            case CLUSTERING:
                k_name.setVisible(true);
                k.setVisible(true);
            break;
            case CONVOLVE:
                kernal.setVisible(true);
            default: break;
        }
        app.revalidate();
    }
}