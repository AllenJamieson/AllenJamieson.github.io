import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

import Display.Display;

public class ImageProcess extends JLabel {
    private JFileChooser file_chooser;
    private JFrame app;
    private String filetype;
    private BufferedImage image, clone;

    public ImageProcess(JFrame app) {
        this.app = app;
        Boolean old = UIManager.getBoolean("FileChooser.readOnly");
        UIManager.put("FileChooser.readOnly", Boolean.TRUE);
        file_chooser = new JFileChooser(".");
        UIManager.put("FileChooser.readOnly", old);
        file_chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        file_chooser.setFileFilter(imageFilter());
        setHorizontalAlignment(CENTER);
    }

    public void save() throws IOException {
        if(clone == null) return;
        int save = file_chooser.showSaveDialog(app);
        if(save == JFileChooser.APPROVE_OPTION) {
            String path = file_chooser.getSelectedFile().getPath();
            File file;
            if(path.contains("." + filetype)) file = new File(path);
            else file = new File(path + "." + filetype);
            ImageIO.write(clone, filetype, file);
            image = clone;
        }
    }

    public void load() throws IOException {
        int return_var = file_chooser.showOpenDialog(app);
        if(return_var == JFileChooser.APPROVE_OPTION) {
            File file = file_chooser.getSelectedFile();
            String name = file.getName();
            filetype = name.substring(name.lastIndexOf(".") + 1);
            image = ImageIO.read(file);
            clone = ImageIO.read(file);
            scaledImage();
        }
    }

    private FileFilter imageFilter() {
        return new FileFilter() {
            @Override
            public boolean accept(File f) {
                String filename = f.getName().toLowerCase();
                return f.isDirectory()
                    || filename.endsWith(".jpeg")
                    || filename.endsWith(".jpg")
                    || filename.endsWith(".png");
            }

            @Override
            public String getDescription() { return "Images"; }
        };
    }

    public void imageEdit(Display d) {
        if(image == null) { System.out.println("No image found"); return; }
        clone = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
        for (int v = 0; v < image.getHeight(); v++)
            for (int h = 0; h < image.getWidth(); h++)
                clone.setRGB(h, v, image.getRGB(h, v));
        d.display(clone);
        clone = d.getTemp();
        scaledImage();
    }

    private void scaledImage() {
        int width = image.getWidth(), height = image.getHeight(), scale = 1;
        while(getWidth() < width/scale || getHeight() < height/scale) scale++;
        BufferedImage scaled_image = new BufferedImage(width/scale, height/scale, BufferedImage.SCALE_SMOOTH);
        scaled_image.createGraphics().drawImage(clone, 0, 0, width/scale, height/scale, null);
        setIcon(new ImageIcon(scaled_image));
    }
} // TODO Merger?