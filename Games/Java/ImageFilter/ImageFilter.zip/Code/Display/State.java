package Display;

public enum State {
    MIN, INVERT, OFF, SAME, MAX
}