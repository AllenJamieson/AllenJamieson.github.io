package Display;

public abstract class Retro extends Display {

    public abstract int[][] colors();

    @Override
    public int[] rewriteImage(int v, int h) {
        int[] rgb = convertRGB(v, h);
        double lowestDist = Integer.MAX_VALUE;
        int[][] colors = colors();
        int color_index = 0;
        for (int c = 0; c < colors.length; c++) {
            double dist = Math.sqrt(
                Math.pow(rgb[0]-colors[c][0], 2) +
                Math.pow(rgb[1]-colors[c][1], 2) +
                Math.pow(rgb[2]-colors[c][2], 2)
            );
            if(lowestDist >= dist) {
                lowestDist = dist;
                color_index = c;
            }
        }
        return colors[color_index];
    }
}