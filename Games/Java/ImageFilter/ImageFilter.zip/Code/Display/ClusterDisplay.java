package Display;
import java.util.ArrayList;

public class ClusterDisplay extends Display {
    private Lloyd k_cluster = new Lloyd();
    private double[][] color_list;
    private int k;

    public ClusterDisplay(int k) {
        this.k = k;
    }

    public void setup() throws Exception {
        k_cluster.clearData();
        ArrayList<double[]> colors = new ArrayList<>();
        for (int v = 0; v < img.getHeight(); v++) {
            for (int h = 0; h < img.getWidth(); h++) {
                int[] rgb = convertRGB(v, h);
                colors.add(new double[] {rgb[0], rgb[1], rgb[2]});
            }
        }
        colors.trimToSize();
        k_cluster.setInput(colors, k);
        color_list = k_cluster.getOutput();
    }

    @Override
    protected int[] rewriteImage(int v, int h) {
        int[] rgb = convertRGB(v, h);
        double minDist = Integer.MAX_VALUE;
        short color_index = 0;
        for (short c = 0; c < color_list.length; c++) {
            double dist = Math.sqrt(
                Math.pow(rgb[0]-color_list[c][0], 2) +
                Math.pow(rgb[1]-color_list[c][1], 2) +
                Math.pow(rgb[2]-color_list[c][2], 2)
            );
            if(minDist > dist) {
                minDist = dist;
                color_index = c;
            }
        }
        return new int[] {
            (int)color_list[color_index][0],
            (int)color_list[color_index][1],
            (int)color_list[color_index][2]
        };
    }
}