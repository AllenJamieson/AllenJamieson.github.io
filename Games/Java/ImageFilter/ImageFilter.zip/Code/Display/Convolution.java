package Display;

// en.wikipedia.org/wiki/Kernel_(image_processing)#Convolution
public class Convolution extends Display {
    private double[][] kernal;

    public Convolution(double[][] kernal) {
        this.kernal = kernal;
    }

    @Override
    public int[] rewriteImage(int v, int h) {
        double[] a = {0, 0, 0};
        for (byte vk = 0; vk < 3; vk++) {
            byte v_offset = (byte)(vk - 1);
            if(v == 0 || v == img.getHeight()-1) v_offset = 0;
            for (byte hk = 0; hk < 3; hk++) {
                byte h_offset = (byte)(hk - 1);
                if(h == 0 || h == img.getWidth()-1) h_offset = 0;
                int[] rgb = convertRGB(v + v_offset, h + h_offset);
                double k = kernal[vk][hk];
                double[] m = {rgb[0] * k, rgb[1] * k, rgb[2] * k};
                a = new double[] {a[0] + m[0], a[1] + m[1], a[2] + m[2]};
            }
        }
        return new int[] {clamp(a[0]), clamp(a[1]), clamp(a[2])};
    }

    private int clamp(double a) {
        if(a < 0) return 0;
        if(a > 0xff) return 0xff;
        return (int) a;
    }
}