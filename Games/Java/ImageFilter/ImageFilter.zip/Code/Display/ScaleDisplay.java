package Display;

public class ScaleDisplay extends Display {
    private State r, g, b;
    private boolean average;
    public ScaleDisplay(State r, State g, State b, boolean average) {
        this.r = r; this.g = g; this.b = b;
        this.average = average;
    }

    @Override
    public int[] rewriteImage(int v, int h) {
        int[] rgb = convertRGB(v, h);
        int red = changeColor(r, rgb[0]),
            green = changeColor(g, rgb[1]),
            blue = changeColor(b, rgb[2]),
            av = (red + green + blue) / 3;
        return average ? new int[] {av, av, av} : new int[] {red, green, blue};
    }

    private int changeColor(State s, int color) {
        switch (s) {
            case MIN: return (color < 255 / 2) ? 0xff : 0;
            case INVERT: return 0xff - color;
            case OFF: return 0;
            case SAME: return color;
            case MAX: return (color > 255 / 2) ? 0xff : 0;
        }
        return 0;
    }
}