package Display;

public class ScaleDisplay extends Display {
    private State r_state, g_state, b_state;
    private String swap_r, swap_g, swap_b;
    private boolean average;
    public ScaleDisplay(State r_state, State g_state, State b_state, String swap_r, String swap_g, String swap_b, boolean average) {
        this.r_state = r_state;
        this.g_state = g_state;
        this.b_state = b_state;
        this.average = average;
        this.swap_r = swap_r;
        this.swap_g = swap_g;
        this.swap_b = swap_b;
    }

    @Override
    public int[] rewriteImage(int v, int h) {
        int[] rgb = convertRGB(v, h);
        int red = changeColor(r_state, rgb[0]),
            green = changeColor(g_state, rgb[1]),
            blue = changeColor(b_state, rgb[2]),
            new_red = red, new_green = green, new_blue = blue;
        if(swap_r.equals("Green")) new_red = green;
        if(swap_r.equals("Blue")) new_red = blue;
        if(swap_g.equals("Red")) new_green = red;
        if(swap_g.equals("Blue")) new_green = blue;
        if(swap_b.equals("Red")) new_blue = red;
        if(swap_b.equals("Green")) new_blue = green;
        int av = (new_red + new_green + new_blue) / 3;
        return average ? new int[] {av, av, av} : new int[] {new_red, new_green, new_blue};
    }

    private int changeColor(State s, int color) {
        switch (s) {
            case MIN: return (color < 255 / 2) ? 0xff : 0;
            case INVERT: return 0xff - color;
            case OFF: return 0;
            case SAME: return color;
            case MAX: return (color > 255 / 2) ? 0xff : 0;
        }
        return 0;
    }
}