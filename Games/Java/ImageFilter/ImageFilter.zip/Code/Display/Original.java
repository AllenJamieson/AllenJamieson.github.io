package Code.Display;

public class Original extends Display {

    @Override
    public void rewriteImage(int v, int h) {}

    @Override
    public String toString() { return "Original"; }
    
}
