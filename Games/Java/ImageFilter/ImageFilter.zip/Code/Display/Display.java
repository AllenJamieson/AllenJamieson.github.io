package Display;
import java.awt.Color;
import java.awt.image.BufferedImage;

public abstract class Display {
    protected BufferedImage img, temp;

    public void display(BufferedImage img) {
        this.img = img;
        this.temp = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
        if(this instanceof ClusterDisplay) {
            try {
                ((ClusterDisplay)this).setup();
            } catch(Exception e) {
                System.out.println("Problem setting up the cluster");
            }
        }
        for (int v = 0; v < img.getHeight(); v++) {
            for (int h = 0; h < img.getWidth(); h++) {
                int[] rgb = rewriteImage(v, h);
                setImage(v, h, rgb);
            }
        }
    }

    private void setImage(int v, int h, int[] rgb) {
        temp.setRGB(h, v, new Color(rgb[0], rgb[1], rgb[2]).getRGB());
    }

    public BufferedImage getTemp() { return temp; }

    protected int[] convertRGB(int v, int h) {
        int color = img.getRGB(h, v);
        return new int[]{
            (color >> 16)   & 0xff,
            (color >> 8)    & 0xff,
            (color)         & 0xff
        };
    }

    protected abstract int[] rewriteImage(int v, int h);
}