import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;

public class PlayerHandler implements Runnable {
    private DataOutputStream out;
    private DataInputStream in;
    private Game game;
    private int port, x, y, health;
    private final byte SPEED = 10;
    public PlayerHandler(Socket socket, Game game) throws IOException {
        this.game = game;
        out = new DataOutputStream(socket.getOutputStream());
        in = new DataInputStream(socket.getInputStream());
        x = y = 0;
        health = 100;
        port = socket.getPort();
        Wall[] walls = game.getWalls();
        String walls_text = Arrays.toString(walls) // TODO Repeated in game
            .replace("[", "")
            .replace("]", "")
            .replaceAll(",", "");
        out.writeUTF(" add_map " + walls_text);
    }

    public DataOutputStream getOut() { return out; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getPort() { return port; }

    @Override
    public void run() {
        try {
            while(true) {
                char move_type = in.readChar();
                int prev_x = x, prev_y = y;
                switch (move_type) {
                    case 'w': if(y > Integer.MIN_VALUE + (2*SPEED)) y -= SPEED; break;
                    case 'a': if(x > Integer.MIN_VALUE + (2*SPEED)) x -= SPEED; break;
                    case 's': if(y < Integer.MAX_VALUE - (2*SPEED)) y += SPEED; break;
                    case 'd': if(x < Integer.MAX_VALUE - (2*SPEED)) x += SPEED; break;
                    default: break;
                }
                // TODO Bullet?
                if(game.moveMap(this)) game.movePlayer(this);
                else { x = prev_x; y = prev_y; }
            }
        } catch (IOException e) {
            System.out.println("Player: " + getPort() + " exited the game");
            try { game.removePlayer(this); }
            catch (IOException e1) { System.out.println("Failed to remove player"); }
        }
    }
}