public class Client {
    public static void main(String[] args) {
        PlayerDisplay player;
        switch (args.length) {
            case 1:
                try {
                    int port = Integer.parseInt(args[0]);
                    player = new PlayerDisplay(port);
                } catch(NumberFormatException e) {
                    player = new PlayerDisplay(args[0]);
                }
            break;
            case 2:
                int port;
                String host;
                try {
                    port = Integer.parseInt(args[0]);
                    host = args[1];
                }
                catch (NumberFormatException e) {
                    port = Integer.parseInt(args[1]);
                    host = args[0];
                }
                System.out.println(port);
                System.out.println(host);
                player = new PlayerDisplay(host, port);
            break;
            default:
                player = new PlayerDisplay();
            break;
        }
        new Thread(player).start();
    }
}
