import java.io.IOException;

public class Server {
    public static void main(String[] args) {
        try {
            if(args.length > 0) new Game(Integer.parseInt(args[0]));
            else new Game();
        } catch (IOException e) {
            System.out.println("Server issue");
        }
    }
}