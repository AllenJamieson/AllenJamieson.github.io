import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class PlayerDisplay extends JFrame implements Runnable {
    private final int WINDOW_WIDTH = 1000, WINDOW_HEIGHT = 500; // TODO Needed or use fulscreen?
    private final byte PLAYER_SIZE = 50; // TODO Hapens to wall collisions
    private final int X_CENTER, Y_CENTER;
    private Socket socket;
    private DataOutputStream out;
    private ArrayList<JLabel> players;
    private ArrayList<JLabel> walls;
    private JLabel health;
    
    public PlayerDisplay() { this("localhost", 1234); }
    public PlayerDisplay(String host) { this(host, 1234); }
    public PlayerDisplay(int port) { this("localhost", port); }

    public PlayerDisplay(String host, int port) {
        X_CENTER = (WINDOW_WIDTH - PLAYER_SIZE) / 2;
        Y_CENTER = (WINDOW_HEIGHT - PLAYER_SIZE) / 2;
        players = new ArrayList<>();
        walls = new ArrayList<>();
        try {
            socket = new Socket(host, port);
            out = new DataOutputStream(socket.getOutputStream());
        } catch(IOException e) {
            System.out.println("Cannot Connect to Game:\n" + e.getMessage());
            System.exit(0);
        }

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                try {
                    if(e.getKeyCode() == KeyEvent.VK_ESCAPE) System.exit(0);
                    out.writeChar(e.getKeyChar());
                } catch (IOException e1) {
                    System.out.println("Writting error");
                }
            }
        });
        setLayout(null);
        //setUndecorated(true); // TODO add
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Player: " + socket.getLocalPort()); // TODO
        setResizable(false);
        setVisible(true);
        System.out.println("Player: " + socket.getLocalPort() + " entered");
    }

    private void addPlayer(String port) {
        JLabel player = new JLabel();
        player.setOpaque(true);
        player.setBackground(Color.GRAY);
        player.setBounds(X_CENTER, Y_CENTER, PLAYER_SIZE, PLAYER_SIZE);
        player.setText(port);
        players.add(player);
        add(player);
        repaint();
        
        System.out.print("Player Ports: { ");
        for (JLabel p : players) System.out.print(p.getText() + " ");
        System.out.println("}");
    }

    private void removePlayer(byte player) {
        players.get(player).setVisible(false);
        players.remove(player);
    }

    private void move_player(String[] data) {
        JLabel player = players.get(Byte.parseByte(data[0]));
        int x = Integer.parseInt(data[2]);
        int y = Integer.parseInt(data[3]);
        player.setLocation(x + X_CENTER, y + Y_CENTER);
    }

    private void add_map(String[] data) {
        int x = 0, y = 0, w = 0;
        for (short i = 2; i < data.length; i++) {
            int number = Integer.parseInt(data[i]);
            if(i % 4 == 2) x = number + X_CENTER;
            if(i % 4 == 3) y = number + Y_CENTER;
            if(i % 4 == 0) w = number;
            if(i % 4 == 1) {
                JLabel wall = new JLabel();
                wall.setBounds(x, y, w, number);
                wall.setOpaque(true);
                wall.setBackground(Color.BLACK);
                walls.add(wall);
                add(wall);
            }
        }
    }

    private void move_map(String[] data) {
        for (short w = 0; w < walls.size(); w++) {
            int x = Integer.parseInt(data[w*2+2]);
            int y = Integer.parseInt(data[w*2+3]);
            walls.get(w).setLocation(x + X_CENTER, y + Y_CENTER);
        }
    }

    @Override
    public void run() {
        try {
            DataInputStream in = new DataInputStream(socket.getInputStream());
            while(true) {
                String[] data = in.readUTF().split(" ");
                System.out.println("Action: " + data[1]);
                
                switch (data[1]) {
                    case "add_player": addPlayer(data[2]); break;
                    case "remove_player": removePlayer(Byte.parseByte(data[0])); break;
                    case "move_player": move_player(data); break;
                    case "add_map": add_map(data); break;
                    case "move_map": move_map(data); break;
                    default: System.out.println("No action"); break;
                }
            }
        } catch (IOException e) { System.out.println("Server Closed"); System.exit(0); }
    }
}