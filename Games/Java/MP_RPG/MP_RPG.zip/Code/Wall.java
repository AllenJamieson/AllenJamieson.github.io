public class Wall {
    private int x, y, w, h;
    public Wall(int x, int y, int w, int h) {
        this.x = x; this.y = y;
        this.w = w; this.h = h;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }

    public boolean is_colliding(int player_x, int player_y) {
        int player_size = 50; // TODO PLAYER SIZE
        return player_x < w + x && player_x + player_size > x
            && player_y < h + y && player_y + player_size > y;
    }

    @Override
    public String toString() {
        return x + " " + y + " " + w + " " + h;
    }
}
