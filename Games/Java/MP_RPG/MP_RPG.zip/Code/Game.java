import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

public class Game  {
    private ArrayList<PlayerHandler> players;
    private Wall[] walls = { // TODO Maps?
        new Wall(-50, 200, 1000, 20),
        new Wall(-50, -200, 1000, 20),
        new Wall(-50, -200, 20, 400),
        new Wall(500, 0, 50, 50)
    };

    public Game() throws IOException { this(1234); }

    public Game(int port) throws IOException {
        ServerSocket server = new ServerSocket(port);
        players = new ArrayList<>();
        System.out.println("Server Connection Success\n" + InetAddress.getLocalHost().getHostName());
        while(players.size() < Byte.MAX_VALUE) {
            Socket player = server.accept();
            System.out.println("Player: " + player.getPort() + " entered the game");
            PlayerHandler player_handler = new PlayerHandler(player, this);
            players.add(player_handler);
            addPlayer(player_handler);
            new Thread(player_handler).start();
        }
        System.out.println("Game is full\n No more players will be added in this session");
    }

    private void addPlayer(PlayerHandler handler) throws IOException {
        for (byte p = 0; p < players.size(); p++) {
            PlayerHandler player = players.get(p);
            player.getOut().writeUTF(p + " add_player " + player.getPort());
            if(!player.equals(handler))
                handler.getOut().writeUTF(p + " add_player " + player.getPort());
        }
        movePlayer(handler); // TODO Implement better?
    }

    protected void removePlayer(PlayerHandler handler) throws IOException {
        byte id = (byte)players.indexOf(handler);
        for (byte p = 0; p < players.size(); p++) {
            PlayerHandler player = players.get(p);
            if(!player.equals(handler)) {
                player.getOut().writeUTF(id + " remove_player " + handler.getPort());
            }
        }
        players.remove(id);
    }

    protected void movePlayer(PlayerHandler handler) throws IOException {
        byte id = (byte)players.indexOf(handler);
        for (byte p = 0; p < players.size(); p++) {
            PlayerHandler player = players.get(p);
            if(handler == null || !player.equals(handler)) {
                int x = handler.getX() - player.getX();
                int y = handler.getY() - player.getY();
                player.getOut().writeUTF(id + " move_player " + x + " " + y);
                handler.getOut().writeUTF(p + " move_player " + -x + " " + -y);
            }
        }
    }

    protected boolean moveMap(PlayerHandler player) throws IOException {
        int[] wall_positions = new int[walls.length * 2];
        int i = 0;
        for (int w = 0; w < walls.length; w++) {
            Wall wall = walls[w];
            if(wall.is_colliding(player.getX(), player.getY())) {
                return false;
            }
            wall_positions[i++] = wall.getX() - player.getX();
            wall_positions[i++] = wall.getY() - player.getY();
        }
        String positions = Arrays.toString(wall_positions)
            .replace("[", "")
            .replace("]", "")
            .replaceAll(",", "");
        player.getOut().writeUTF(" move_map " + positions);
        return true;
    }

    public Wall[] getWalls() { return walls; }
}