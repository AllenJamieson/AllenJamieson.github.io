import java.util.ArrayList;
// My iteration of k-mean clustering
public class Lloyd {
    private ArrayList<double[]> verts;
    private ArrayList<ArrayList<double[]>> clusters;
    private double[][] centeroids;
    private int k, vector_size;
    
    public void setInput(ArrayList<double[]> verts, int k) throws Exception {
        System.out.println("Set Inputs...");
        if(verts == null || k < 1) throw new Exception("Either the list is not instansiated or k is negative");
        this.verts = verts;
        this.k = k;
        clusters = new ArrayList<>();
        for (short k1 = 0; k1 < k; k1++) clusters.add(new ArrayList<>());
        clusters.trimToSize();
        vector_size = verts.get(0).length;
    }

    public double[][] getOutput() throws Exception {
        System.out.println("Computing the image into " + k + " clusters");
        if(verts == null || k < 1) throw new Exception("Either the list is not instansiated or k is negative");
        initializeCenters();
        int iter = 0;
        boolean cont = true;
        while(cont == true) {
            double[][] temp = clone(centeroids);
            assignPoints(); 
            computeCenteroid();
            cont = false;
            iter++;
            for (short c = 0; c < temp.length; c++) {
                for (int i = 0; i < temp[0].length; i++) {
                    double size = Math.abs(centeroids[c][i] - temp[c][i]);
                    if(size > 0.001) cont = true;
                }
            }
        }
        System.out.println(iter);
        return centeroids;
    }

    private void initializeCenters() {
        centeroids = new double[k][verts.get(0).length];
        for (short c = 0; c < k; c++) centeroids[c] = verts.get(c);
    }

    private void assignPoints() throws Exception {
        for (ArrayList<double[]> c : clusters) c.clear();
        for (int vert = 0; vert < verts.size(); vert++) {
            double min = Integer.MAX_VALUE;
            int k1 = -1;
            for (short center = 0; center < k; center++) {
                double sum = 0;
                for (int i = 0; i < vector_size; i++)
                    sum += (Math.pow((verts.get(vert)[i] - centeroids[center][i]), 2));
                sum = Math.sqrt(sum);
                if(sum < min) {
                    min = sum;
                    k1 = center;
                }
            }
            clusters.get(k1).add(verts.get(vert));
        }
    }

    private void computeCenteroid() {
        for (short cluster = 0; cluster < k; cluster++) {
            int size = clusters.get(cluster).size();
            double[] sum = new double[vector_size];
            if(size == 0) continue;
            for (int val = 0; val < size; val++) sum = add(sum, clusters.get(cluster).get(val));
            for (short i = 0; i < vector_size; i++) centeroids[cluster][i] = sum[i]/size;
        }
    }

    private double[] add(double[] a, double[] b) {
        for (int i = 0; i < a.length; i++) a[i] += b[i];
        return a;
    }

    private double[][] clone(double[][] a) {
        double[][] b = new double[a.length][a[0].length];
        for (int c = 0; c < b.length; c++)
            for (int i = 0; i < b[0].length; i++)
                b[c][i] = a[c][i];
        return b;
    }

    public void clearData() {
        verts = null;
        clusters = null;
        centeroids = null;
        k = 0;
        vector_size = 0;
    }
}