import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

public class ImageSetup {
    private JFrame app;
    private JFileChooser chooser;
    private BufferedImage image;
    private String type;
    private JLabel label;
    private Lloyd k_cluster;
    private int width, height;

    public ImageSetup(JFrame app, int width, int height) {
        this.app = app;
        this.width = width;
        this.height = height;
        label = new JLabel();
        k_cluster = new Lloyd();
        Boolean old = UIManager.getBoolean("FileChooser.readOnly");
        UIManager.put("FileChooser.readOnly", Boolean.TRUE);
        chooser = new JFileChooser(".");
        UIManager.put("FileChooser.readOnly", old);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setFileFilter(imageFilter());
    }

    public void load(short k) {
        int returnVar = chooser.showOpenDialog(app);
        System.out.println("Loading in an image");
        if(returnVar == JFileChooser.APPROVE_OPTION) {
            try {
                File chosen = chooser.getSelectedFile();
                type = chosen.getPath().split("\\.")[1];
                image = ImageIO.read(chosen);
                convert(image, k_cluster, k);
                scaleImage();
            }
            catch (Exception e) { System.out.println("Image not found"); }
        }
    }

    public void save(String return_path) { // TODO Better save location system
        try { ImageIO.write(image, type, new File(return_path + "." + type)); }
        catch (IOException e) { e.printStackTrace(); }
    }

    private FileFilter imageFilter() {
        return new FileFilter() {
            @Override
            public boolean accept(File f) {
                String fileName = f.getName();
                return f.isDirectory()
                    || fileName.endsWith(".jpeg")
                    || fileName.endsWith(".jpg")
                    || fileName.endsWith(".png");
            }

            @Override
            public String getDescription() {
                return "Images";
            }
        };
    }

    private void scaleImage() {
        System.out.println("\nScaling Image");
        int scale = 1,
            imageWidth = image.getWidth(), imageHeight = image.getHeight();
        System.out.println(
            "Width: " + width + "\n" + "Height: " + height + "\n" +
            "Original Width: " + imageWidth + "\n" + "Original Height " + imageHeight
        );
        BufferedImage scaledImage = image;
        if(width <= imageWidth || height <= imageHeight) {
            while(width <= imageWidth/scale) scale++;
            while(height <= imageHeight/scale) scale++;
            scaledImage = new BufferedImage(imageWidth/scale, imageHeight/scale, BufferedImage.SCALE_SMOOTH);
            scaledImage.createGraphics().drawImage(image, 0, 0, imageWidth/scale, imageHeight/scale, null);
        }
        System.out.println("Scaled by: " + scale);
        label.setIcon(new ImageIcon(scaledImage));
    }

    private BufferedImage convert(BufferedImage image, Lloyd k_cluster, int k) throws Exception {
        k_cluster.clearData();
        ArrayList<double[]> colors = new ArrayList<>();
        for (int v = 0; v < image.getHeight(); v++) {
            for (int h = 0; h < image.getWidth(); h++) {
                int c = image.getRGB(h, v);
                colors.add(new double[] { (c & 0x00ff0000) >> 16, (c & 0x0000ff00) >> 8, c & 0x000000ff });
            }
        }
        colors.trimToSize();
        k_cluster.setInput(colors, k);
        double[][] color_list = k_cluster.getOutput();
        
        for (int v = 0; v < image.getHeight(); v++) {
            for (int h = 0; h < image.getWidth(); h++) {
                int actred = (image.getRGB(h, v) & 0x00ff0000) >> 16,
                    actgreen = (image.getRGB(h, v) & 0x0000ff00) >> 8,
                    actblue = image.getRGB(h, v) & 0x000000ff;
                double minDist = Integer.MAX_VALUE;
                short colorIndex = 0;
                for (short c = 0; c < color_list.length; c++) {
                    int cred = toInt(color_list[c][0]),
                        cgreen = toInt(color_list[c][1]),
                        cblue = toInt(color_list[c][2]);
                    double dist = Math.sqrt(Math.pow(actred-cred, 2) + Math.pow(actgreen-cgreen, 2) + Math.pow(actblue-cblue, 2));
                    if(minDist > dist) {
                        minDist = dist;
                        colorIndex = c;
                    }
                }
                image.setRGB(h, v, new Color(toInt(color_list[colorIndex][0]), toInt(color_list[colorIndex][1]), toInt(color_list[colorIndex][2])).getRGB());
            }
        }
        return image;
    }

    private int toInt(double d) { return (int)(d + 0.5); }

    public JLabel getLabel() { return label; }
    public void setImage(BufferedImage image) { this.image = image; }
}