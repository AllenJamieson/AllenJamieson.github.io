import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Display { // TODO Pretty it up
    private ImageSetup imageData;
    private JButton load, save;
    private JTextArea return_path;
    private JComboBox<Short> k;
    private JLabel image;
    private int height = 655, width = 725;
    public Display() {
        JFrame app = new JFrame("Color Cluster");
        imageData = new ImageSetup(app, width, height);
        load = new JButton("Load");
        save = new JButton("Save");
        k = new JComboBox<>(new Short[] {2, 4, 8, 16, 32, 64});
        return_path = new JTextArea();

        image = imageData.getLabel();
        load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                imageData.load((short)k.getSelectedItem());
            }
        });

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                imageData.save(return_path.getText());
            }
        });

        return_path.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        app.setSize(750, 750);
        load.setBounds(5, 5, 100, 30);
        save.setBounds(110, 5, 100, 30);
        k.setBounds(215, 5, 50, 30);
        return_path.setBounds(270, 5, 400, 30);
        image.setBounds(5, 40, width, height);

        app.add(load);
        app.add(save);
        app.add(k);
        app.add(return_path);
        app.add(image);
        app.setLayout(null);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    }

}
