import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MaxColor {

    private final int NUM_COLORS = 16;
    private final short SCALE = 2;

    public MaxColor() throws IOException {
        BufferedImage image = ImageIO.read(new File("Catwoman.png"));
        BufferedImage smallimage = new BufferedImage(image.getWidth()/SCALE, image.getHeight()/SCALE, BufferedImage.TYPE_INT_RGB);
        smallimage.createGraphics().drawImage(image, 0, 0, image.getWidth()/SCALE, image.getHeight()/SCALE, null);
        image = smallimage;

        ArrayList<ColorData> colors = new ArrayList<>();
        for (int v = 0; v < image.getHeight(); v++) {
            for (int h = 0; h < image.getWidth(); h++) {
                int color = image.getRGB(h, v);
                boolean exists = false;
                int c = -1;
                for (int co = 0; co < colors.size(); co++) {
                    if(colors.get(co).exists(color)) {
                        exists = true;
                        c = co;
                        break;
                    }
                }
                if(exists == false) { colors.add(new ColorData(color)); }
                else colors.get(c).add();
            }
        }
        Collections.sort(colors);
        for (int c = 0; c < NUM_COLORS; c++) {
            System.out.println(colors.get(c));
            System.out.println(colors.get(c).getCount());
        }

        JFrame app = new JFrame();
        app.setLayout(null);
        for (int c = 0; c < NUM_COLORS; c++) {
            JLabel colorLabel = new JLabel();
            colorLabel.setBackground(colors.get(c).getColorDisplay());
            colorLabel.setOpaque(true);
            colorLabel.setBounds(0+(c*20), 0, 20, 20);
            app.add(colorLabel);
        }
        app.setVisible(true);
    }
}
