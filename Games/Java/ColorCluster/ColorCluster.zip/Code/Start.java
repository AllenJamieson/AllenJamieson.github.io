public class Start {
    public static void main(String[] args) throws Exception {
        new Display();
    }
}