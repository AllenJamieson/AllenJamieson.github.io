import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class Start {
    public static void main(String[] args) throws Exception {
        String path = args[0];
        int k = Integer.parseInt(args[1]);
        String return_path = args[2];
        String type = args[3];

        Lloyd k_cluster = new Lloyd();
        BufferedImage orig = ImageIO.read(new File(path));
        BufferedImage img = convert(orig, k_cluster, k);
        ImageIO.write(img, type, new File(return_path + "." + type));
    }

    
    private static BufferedImage convert(BufferedImage image, Lloyd k_cluster, int k) throws Exception {
        k_cluster.clearData();
        ArrayList<double[]> colors = new ArrayList<>();
        for (int v = 0; v < image.getHeight(); v++) {
            for (int h = 0; h < image.getWidth(); h++) {
                int c = image.getRGB(h, v);
                colors.add(new double[] { (c & 0x00ff0000) >> 16, (c & 0x0000ff00) >> 8, c & 0x000000ff });
            }
        }
        colors.trimToSize();
        k_cluster.setInput(colors, k);
        double[][] color_list = k_cluster.getOutput();
        
        for (int v = 0; v < image.getHeight(); v++) {
            for (int h = 0; h < image.getWidth(); h++) {
                int actred = (image.getRGB(h, v) & 0x00ff0000) >> 16,
                    actgreen = (image.getRGB(h, v) & 0x0000ff00) >> 8,
                    actblue = image.getRGB(h, v) & 0x000000ff;
                double minDist = Integer.MAX_VALUE;
                short colorIndex = 0;
                for (short c = 0; c < color_list.length; c++) {
                    int cred = toInt(color_list[c][0]),
                        cgreen = toInt(color_list[c][1]),
                        cblue = toInt(color_list[c][2]);
                    double dist = Math.sqrt(Math.pow(actred-cred, 2) + Math.pow(actgreen-cgreen, 2) + Math.pow(actblue-cblue, 2));
                    if(minDist > dist) {
                        minDist = dist;
                        colorIndex = c;
                    }
                }
                image.setRGB(h, v, new Color(toInt(color_list[colorIndex][0]), toInt(color_list[colorIndex][1]), toInt(color_list[colorIndex][2])).getRGB());
            }
        }
        return image;
    }

    private static int toInt(double d) { return (int)(d + 0.5); }

}