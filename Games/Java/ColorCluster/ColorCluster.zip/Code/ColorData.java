import java.awt.Color;

public class ColorData implements Comparable<ColorData> {
    private int count;
    private int[] color;

    public ColorData(int color) {
        this.color = getColor(color);
        count = 1;
    }

    public void add() { count++; }
    public int getCount() { return count; }
    public int[] getColor(int c) { return new int[] { (c & 0x00ff0000) >> 16, (c & 0x0000ff00) >> 8, c & 0x000000ff }; }
    public int[] getColor() { return color; }
    public Color getColorDisplay() {return new Color(color[0], color[1], color[2]);}
    public boolean exists(int c) {
        int[] color1 = getColor(c);
        return color[0] == color1[0] && color[1] == color1[1] && color[2] == color1[2];
    }

    @Override
    public int compareTo(ColorData o) { return o.getCount() - count; }

    public double distance(ColorData c) {
        int[] c1 = c.getColor();
        int[] c2 = getColor();
        return Math.sqrt(Math.pow((c1[0] - c2[0]), 2) + Math.pow((c1[1] - c2[1]), 2) + Math.pow((c1[2] - c2[2]), 2));
    }

    @Override
    public String toString() { return "Red: " + color[0] + "\nGreen: " + color[1] + "\nBlue: " + color[2]; }
}