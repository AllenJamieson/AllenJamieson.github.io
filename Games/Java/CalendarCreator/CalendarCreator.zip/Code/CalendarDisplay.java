import java.awt.Font;
import java.awt.GridLayout;
import java.util.Calendar;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class CalendarDisplay {
    private final String[] WEEKS = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private final short SIDE_PADDING = 20;
    private final short MONTH_PADDING = 20;

    public class Month extends JPanel {
        public Month(byte month, String month_name, String[] special_days) {
            indent %= 7;
            JLabel month_text = new JLabel(month_name);
            JPanel weeks = new JPanel(new GridLayout(0, WEEKS.length, -1, -1));
            JPanel table = new JPanel(new GridLayout(0, WEEKS.length, -1, -1));
            setupGrid(weeks, table, special_days, month);
            month_text.setFont(new Font("SansSerif", Font.BOLD, 50));
            month_text.setHorizontalAlignment(JLabel.CENTER);

            setSize(5000, 2500);
            setLayout(null);

            month_text.setBounds(0, MONTH_PADDING, getWidth(), 60);
            weeks.setBounds(SIDE_PADDING, month_text.getHeight() + (2*MONTH_PADDING),
                            getWidth() - (2*SIDE_PADDING), 50);
            table.setBounds(SIDE_PADDING, weeks.getY() + weeks.getHeight() - 3,
                            getWidth() - (2*SIDE_PADDING), getHeight()-weeks.getY()-weeks.getHeight()-MONTH_PADDING);
            
            add(month_text);
            add(weeks);
            add(table);
        }

        private void setupGrid(JPanel weeks, JPanel table, String[] special_days, byte month) {
            byte month_size = 31;
            if(month == 3 || month == 5 || month == 8 || month == 10) month_size = 30;
            if(month == 1) month_size = 28;
            if(month == 1 && leap_year) month_size = 29;
            for (String day : WEEKS) weeks.add(new Day(day));

            byte start_date = 1;
            boolean next_day = true;
            while (next_day) {
                for (byte h = 0; h < WEEKS.length; h++) {
                    if(start_date > month_size) next_day = false;
                    else if(h < indent && start_date == 1) table.add(new Day(""));
                    else {
                        table.add(new Day("" + start_date + "<br><br>" + special_days[start_date-1]));
                        indent++;
                        start_date++;
                    }
                }
            }
        }
    }

    private Month[] months;
    private String[] month_names;
    private byte indent = 0;
    private boolean leap_year = false;
    private int year;

    public CalendarDisplay(int year, String[] month_names) {
        this.year = year;
        this.month_names = month_names;
        months = new Month[month_names.length];
    }

    public void createCalendar() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, 0, 0);
        indent = (byte) (calendar.get(Calendar.DAY_OF_WEEK));

        // https://www.geeksforgeeks.org/dsa/program-check-given-year-leap-year/
        if(year % 4 == 0) {
            if(year % 100 == 0) leap_year = year % 400 == 0;
            leap_year = true;
        }
        String[][] days = new ParseDays(month_names, year).getDay_info();
        for (byte month = 0; month < month_names.length; month++)
            months[month] = new Month(month, month_names[month], days[month]);
    }

    public Month getMonth(byte m) { return months[m]; }
    public void setYear(int year) { this.year = year; }
}