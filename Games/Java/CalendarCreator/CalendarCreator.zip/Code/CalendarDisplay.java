import java.awt.Font;
import java.util.Calendar;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class CalendarDisplay {
    private final String[] WEEKS = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Sunday"};

    public class Month extends JPanel {
        public Month(byte month, String month_name, boolean leap_year, String[] special_days) {
            indent %= 7;
            byte month_size = 31;
            if(month == 3 || month == 5 || month == 8 || month == 10) month_size = 30;
            if(month == 1) month_size = 28;
            if(month == 1 && leap_year) month_size = 29;

            byte height = (byte) ((month_size + indent) / 7);
            if((month_size + indent) % 7 > 0) height++;

            JTable header = new JTable(1, 7);
            JTable table = new JTable(height, 7);
            header.setEnabled(false);
            table.setEnabled(false);
            table.setFont(new Font("Times New Roman", Font.ROMAN_BASELINE, 12));
            //https://forums.codeguru.com/showthread.php?40356-aligning-text-in-JTable
            DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
            renderer.setVerticalAlignment(DefaultTableCellRenderer.TOP);
            table.setRowHeight(175); // https://www.codejava.net/java-se/swing/setting-column-width-and-row-height-for-jtable
            for (byte w = 0; w < WEEKS.length; w++) {
                header.setValueAt(WEEKS[w], 0, w);
                table.getColumn(table.getColumnName(w)).setCellRenderer(renderer);
            }
            byte start_date = 1;
            for (byte v = 0; v < height; v++) {
                for (byte h = 0; h < WEEKS.length; h++) {
                    if(h < indent && v == 0) continue;
                    else if(start_date > month_size) continue;
                    else {
                        String text = "<html>" + start_date + "<br>" + special_days[start_date-1] + "</html>";
                        table.setValueAt(text, v, h);
                        indent++;
                        start_date++;
                    }
                }
            }
            // https://stackoverflow.com/questions/2975489/what-is-the-best-way-to-put-spaces-between-objects-can-a-swing-jseparator-objec
            JLabel month_text = new JLabel(month_name);
            month_text.setFont(new Font("Times New Roman", Font.BOLD, 50));
            month_text.setAlignmentX(JLabel.CENTER_ALIGNMENT); 
            setSize(2000, 1000);
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            add(Box.createHorizontalStrut(1));
            add(month_text);
            add(Box.createHorizontalStrut(1));
            add(header);
            add(table);
            add(Box.createHorizontalStrut(1));
        }
    }

    Month[] months;
    byte indent = 0;

    public CalendarDisplay(int year, String[] month_names) {
        months = new Month[month_names.length];
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, 0, 0);
        indent = (byte) (calendar.get(Calendar.DAY_OF_WEEK));

        // https://www.geeksforgeeks.org/dsa/program-check-given-year-leap-year/
        boolean leap_year = false;
        if(year % 4 == 0) {
            if(year % 100 == 0) {
                leap_year = year % 400 == 0;
            }
            leap_year = true;
        }

        String[][] days = new ParseDays(month_names, year).getDay_info();
        for (byte month = 0; month < month_names.length; month++)
            months[month] = new Month(month, month_names[month], leap_year, days[month]);
    }

    public Month getMonth(byte m) { return months[m]; }
}