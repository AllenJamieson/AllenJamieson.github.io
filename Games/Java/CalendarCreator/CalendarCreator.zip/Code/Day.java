import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Day extends JLabel {
    private final short IMG_HEIGHT = 400;
    private final short IMG_WIDTH = 400;

    public Day(String info) {
        // https://stackoverflow.com/questions/22384414/how-can-i-set-the-margin-of-a-jlabel
        Border line = new LineBorder(Color.BLACK);
        Border margin = new EmptyBorder(5, 5, 0, 5);
        setBorder(new CompoundBorder(line, margin));
        setFont(new Font("SansSerif", Font.PLAIN, 24));
        setHorizontalTextPosition(LEFT);
        setVerticalTextPosition(TOP);
        setVerticalAlignment(TOP);
        
        if(info.contains("image: ")) {
            String[] items = info.split("image: ");
            try {
                BufferedImage image = ImageIO.read(new File(items[1]));
                BufferedImage scaled = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_ARGB);
                scaled.createGraphics().drawImage(image, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
                setIcon(new ImageIcon(scaled));
                info = items[0];
            } catch (IOException e) {}
        }
        setText("<html>" + info + "</html>");
    }
}
