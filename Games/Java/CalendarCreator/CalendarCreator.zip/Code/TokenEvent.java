import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;

import javax.swing.JPanel;

public class TokenEvent extends MouseAdapter {
    private Token label;
    private JPanel panel;
    private int x_offset = 0, y_offset = 0;
    public TokenEvent(Token label, JPanel panel) {
        this.label = label;
        this.panel = panel;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        int button = e.getButton();
        x_offset = e.getX();
        y_offset = e.getY();

        // TODO Find out the more intuitive mouse thing
        if(e.isControlDown()) {
            if(button == MouseEvent.BUTTON1) label.flip();
            if(button == MouseEvent.BUTTON3) {
                panel.remove(label);
                panel.repaint();
            }
        } else {
            if(button == MouseEvent.BUTTON3) {
                Component[] items = panel.getComponents();
                for (Component component : items)
                    if(!label.equals(component)) 
                        panel.setComponentZOrder(component, 0); // TODO Find better way to move the image front or back in z axis
                panel.repaint();
            }
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        int x = e.getXOnScreen() - x_offset - panel.getX(),
            y = e.getYOnScreen() - y_offset - panel.getY();
        label.setLocation(x, y);
        panel.setComponentZOrder(label, 0);
    }
    
    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        double scale = e.getWheelRotation() == 1 ? (9.0/10.0) : (10.0/9.0); // TODO update to desired scaling
        int x = (int)(e.getXOnScreen() - (e.getX() * scale) - panel.getX()),
            y = (int)(e.getYOnScreen() - (e.getY()*scale) - panel.getY()),
            h = (int) (label.getHeight() * scale),
            w = (int) (label.getWidth() * scale);
        label.setLocation(x, y);
        label.setSize(w, h);
        label.scaleImage(w, h);
    }
}