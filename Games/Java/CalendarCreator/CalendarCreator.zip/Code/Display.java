import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Year;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;

public class Display extends JFrame {

    private final int MOVE_DISTANCE = 20;
    private final String[] MONTHS;
    private ImageEditer[] month_panels;

    public Display(String[] months) {
        MONTHS = months;
        setTitle("Calendar");
        int year = Year.now().getValue();

        JSpinner year_select = new JSpinner();
        year_select.setValue(year);

        JPanel month_control = new JPanel();
        month_panels = new ImageEditer[MONTHS.length];
        for (byte month = 0; month < MONTHS.length; month++) {
            byte m = month;
            JFrame pane = new JFrame(MONTHS[m]);
            month_panels[m] = new ImageEditer(pane);
            
            pane.setLayout(null);
            month_panels[m].setLocation(0, 0);
            
            pane.setSize(Toolkit.getDefaultToolkit().getScreenSize());
            pane.setUndecorated(true);
            pane.add(month_panels[m]);
            pane.addKeyListener(new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent e) {
                    if(e.getKeyCode() == KeyEvent.VK_ESCAPE) pane.setVisible(false);
                }
                @Override
                public void keyPressed(KeyEvent e) {
                    int x = month_panels[m].getX(),
                        y = month_panels[m].getY();
                    if(e.getKeyChar() == 'w')  y += MOVE_DISTANCE;
                    if(e.getKeyChar() == 'a') x += MOVE_DISTANCE;
                    if(e.getKeyChar() == 's') y -= MOVE_DISTANCE;
                    if(e.getKeyChar() == 'd') x -= MOVE_DISTANCE;
                    month_panels[m].setLocation(x, y);
                }
            });
            JButton button = new JButton(MONTHS[m]);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) { pane.setVisible(true); }
            });
            month_control.add(button);
        }

        JButton save = new JButton("Save");
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { saveCalendar((int) year_select.getValue()); }
        });

        add(year_select);
        add(month_control);
        add(save);

        setSize(1200, 100);
        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(new FlowLayout(FlowLayout.CENTER));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // https://stackoverflow.com/questions/1349220/convert-jpanel-to-image
    private void panelToImage(JPanel panel, String text) {
        JFrame app = new JFrame();
        app.add(panel);
        app.setSize(panel.getWidth(), panel.getHeight());
        app.setUndecorated(true);
        app.setVisible(true);
        BufferedImage image = new BufferedImage(panel.getWidth(), panel.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics2d = image.createGraphics();
        panel.paint(graphics2d);
        graphics2d.dispose();
        System.out.println(text);
        try { ImageIO.write(image, "png",  new File("Calendar/" + text)); }
        catch (IOException e) {}
    }

    private void saveCalendar(int year) {
        int quit = JOptionPane.showConfirmDialog(null, "By Saving, The window will close. Do you wish to continue?");
        if(quit != 0) return;
        CalendarDisplay cd = new CalendarDisplay(year, MONTHS);

        for (byte m = 0; m < MONTHS.length; m++) {
            JPanel month_panel = cd.getMonth(m);
            JPanel image_panel = month_panels[m];
            panelToImage(month_panel, "" + year + "_" + MONTHS[m] + "_table.png");
            panelToImage(image_panel, "" + year + "_" + MONTHS[m] + "_image.png");
        }
        System.exit(0);
    }
}