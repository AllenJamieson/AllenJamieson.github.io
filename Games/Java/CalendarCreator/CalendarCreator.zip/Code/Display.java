import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Year;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Display extends JFrame {

    private final short LINE_PADDING = 3;
    private final String[] MONTHS = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

    private CalendarDisplay calendar;
    private ImageEditer[] month_panels;
    private int year;
    private Font font = new Font("SansSarif", Font.PLAIN, 16);

    public Display() {
        setTitle("Calendar");
        year = Year.now().getValue() + 1;
        calendar = new CalendarDisplay(year, MONTHS);
        calendar.createCalendar();

        JLabel year_label = new JLabel("Year");
        JSpinner year_select = new JSpinner();
        JPanel month_control = new JPanel();
        JButton save_calendar = new JButton("Save Calendar");
        JButton save_all = new JButton("Save All");


        // https://stackoverflow.com/questions/8440754/remove-comma-from-jspinner
        JSpinner.NumberEditor editor = new JSpinner.NumberEditor(year_select, "#");
        year_label.setFont(font);
        year_select.setEditor(editor);
        year_select.setValue(year);
        year_select.setFont(font);
        month_control.setLayout(new GridLayout(MONTHS.length, 3, 0, LINE_PADDING));
        month_control.setBackground(Color.BLACK);
        month_control.setBorder(new EmptyBorder(LINE_PADDING, LINE_PADDING, LINE_PADDING, LINE_PADDING));
        setupPanels(month_control);
        
        year_select.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                year = (int) year_select.getValue();
                calendar.setYear(year);
            }
        });
        save_calendar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calendar.createCalendar();
                for (byte m = 0; m < MONTHS.length; m++) {
                    JPanel month_panel = calendar.getMonth(m);
                    panelToImage(month_panel, "" + year + "_" + MONTHS[m] + "_table.png");
                }
            }
        });
        save_all.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calendar.createCalendar();
                for (byte m = 0; m < MONTHS.length; m++) {
                    JPanel month_panel = calendar.getMonth(m);
                    JPanel image_panel = month_panels[m];
                    panelToImage(month_panel, "" + year + "_" + MONTHS[m] + "_table.png");
                    panelToImage(image_panel, "" + year + "_" + MONTHS[m] + "_image.png");
                }
            }
        });

        add(year_label);
        add(year_select);
        add(month_control);
        add(save_calendar);
        add(save_all);

        setSize(350, 500);
        setLayout(new FlowLayout(FlowLayout.CENTER));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // https://stackoverflow.com/questions/1349220/convert-jpanel-to-image
    private void panelToImage(JPanel panel, String text) {
        JFrame app = new JFrame();
        app.add(panel);
        app.setSize(panel.getWidth(), panel.getHeight());
        app.setUndecorated(true);
        app.setVisible(true);
        BufferedImage image = new BufferedImage(panel.getWidth(), panel.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics2d = image.createGraphics();
        panel.paint(graphics2d);
        graphics2d.dispose();
        System.out.println(text);
        try { ImageIO.write(image, "png",  new File("Calendar/" + text)); }
        catch (IOException e) { System.out.println("Image Failed to Write");}
        app.dispose();
    }

    private void setupPanels(JPanel month_control) {
        month_panels = new ImageEditer[MONTHS.length];

        // Create the panels that can be edited
        for (byte month = 0; month < MONTHS.length; month++) {
            byte m = month;
            JFrame pane = new JFrame();
            month_panels[m] = new ImageEditer(pane);
            pane.setLayout(null);            
            pane.setSize(month_panels[m].getSize());
            pane.setUndecorated(true);
            pane.add(month_panels[m]);
            
            JLabel month_name = new JLabel(MONTHS[m]);
            JButton edit = new JButton("Edit Image");
            JButton save = new JButton("Save Image");
            month_name.setOpaque(true);
            month_name.setFont(font);
            
            edit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) { pane.setVisible(true); }
            });
            save.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    panelToImage(month_panels[m], "" + year + "_" + MONTHS[m] + "_image.png");
                }
            });
            month_control.add(month_name);
            month_control.add(edit);
            month_control.add(save);
        }
    }
}