import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ParseDays {
    private String[][] day_info;

    public ParseDays(String[] months, int current_year) {
        System.out.println("Reading data...");
        day_info = new String[months.length][31];
        for (byte m = 0; m < months.length; m++)
            for (byte d = 0; d < 31; d++)
                day_info[m][d] = "";
        
        String title = "";
        try {
            Scanner scan = new Scanner(new File("special_days.txt"));
            while(scan.hasNextLine()) {
                String line = scan.nextLine();
                if(line.equals("")) continue;
                String[] tokens = line.split(":");
                if(tokens.length == 1) title = tokens[0];
                else {
                    String name = tokens[0].trim();
                    String[] date_tokens = tokens[1].trim().split("/");
                    int day = Integer.parseInt(date_tokens[0])-1,
                        month = Integer.parseInt(date_tokens[1])-1;
                    if(title.equals("Holiday")) {
                        if(tokens.length == 2) day_info[month][day] += ("<p color=red>" + name + "</p><br>");
                        else day_info[month][day] += ("image: " + tokens[2].trim());
                    } else {
                        // Death is wrong
                        if(tokens.length == 2) day_info[month][day] += ("Happy " + numSufix(current_year - Integer.parseInt(date_tokens[2])) + " " + title + " " + name + "<br>");
                        else day_info[month][day] += ("We miss you " + name + " (" + date_tokens[2] + ")<br>");
                    }
                }
            }
            scan.close();
        } catch (FileNotFoundException e) { System.out.println("No file to parse.\nAdd special_days.txt"); }
    }

    private String numSufix(int num) {
        byte first_digit = (byte) (num % 10);
        if(first_digit >= 4 || num == 11 || num == 12 || num == 13 || first_digit == 0) return num + "th";
        if(first_digit == 1) return num + "st";
        if(first_digit == 2) return num + "nd";
        if(first_digit == 3) return num + "rd";
        return "" + num;
    }

    public String[][] getDay_info() { return day_info; }
}