import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileFilter;

public class ImageEditer extends JPanel {
    private final int WIDTH = 5000, HEIGHT = 2500;
    private final int MOVE_DISTANCE = 20;
    private final int SCALED_W, SCALED_H;

    private JFileChooser chooser;
    private JFrame app;
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    private int x_offset, y_offset;
    
    public ImageEditer(JFrame app) {
        this.app = app;
       
        setSize(WIDTH, HEIGHT);
        double width_ratio = WIDTH / dim.getWidth();
        double height_ratio = HEIGHT / dim.getHeight();
        double scale = height_ratio > width_ratio ? height_ratio : width_ratio;
        SCALED_W = (int)(WIDTH/scale);
        SCALED_H = (int)(HEIGHT/scale);

        setLayout(null);
        setBorder(new LineBorder(Color.BLACK));
        setupChooser();
        setupListeners();
        setFocusable(true);
    }

    private void setupChooser() {
        Boolean old = UIManager.getBoolean("FileChooser.readOnly");
        UIManager.put("FileChooser.readOnly", Boolean.TRUE);
        chooser = new JFileChooser(".");
        UIManager.put("FileChooser.readOnly", old);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setFileFilter(imageFilter());
    }

    private void setupListeners() {
        MouseAdapter adapter = adapter();
        addMouseListener(adapter);
        addMouseMotionListener(adapter);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int x = getX(),
                    y = getY();
                if(e.getKeyChar() == 'w') y += MOVE_DISTANCE;
                if(e.getKeyChar() == 'a') x += MOVE_DISTANCE;
                if(e.getKeyChar() == 's') y -= MOVE_DISTANCE;
                if(e.getKeyChar() == 'd') x -= MOVE_DISTANCE;
                setLocation(x, y);
            }
            @Override
            public void keyReleased(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_END) app.setVisible(false);
                if(e.getKeyCode() == KeyEvent.VK_SPACE) scalePanel();
            }
        });
    }

    private FileFilter imageFilter() {
        return new FileFilter() {
            @Override
            public boolean accept(File f) {
                String fileName = f.getName().toLowerCase();
                return f.isDirectory()
                    || fileName.endsWith(".jpeg")
                    || fileName.endsWith(".jpg")
                    || fileName.endsWith(".png");
            }

            @Override
            public String getDescription() {
                return "Images";
            }
        };
    }

    private void openImage(MouseEvent e) {
        int return_var = chooser.showOpenDialog(app);
        if(return_var == JFileChooser.APPROVE_OPTION) {
            try {
                BufferedImage im = ImageIO.read(chooser.getSelectedFile());
                Token t = new Token(im, e.getX(), e.getY(), this);
                add(t);
                setComponentZOrder(t, 0);
                repaint();
            } catch (IOException e1) { System.out.println("Image cannot be rendered"); }
        }
    }

    private void scalePanel() {
        JFrame scaled = new JFrame();
        BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
        BufferedImage scaled_image = new BufferedImage(SCALED_W, SCALED_H, BufferedImage.SCALE_SMOOTH);
        paint(image.createGraphics());
        scaled_image.createGraphics().drawImage(image, 0, 0, SCALED_W, SCALED_H, null);

        scaled.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_SPACE) scaled.dispose();
            }
        });
        scaled.add(new JLabel(new ImageIcon(scaled_image)));
        scaled.setSize(SCALED_W, SCALED_H);
        scaled.setUndecorated(true);
        scaled.setVisible(true);
    }

    private MouseAdapter adapter() {
        return new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                x_offset = e.getX();
                y_offset = e.getY();
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if(e.getButton() == MouseEvent.BUTTON1 && isFocusOwner()) openImage(e);
                grabFocus();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - x_offset,
                    y = e.getYOnScreen() - y_offset;
                setLocation(x, y);
            }
        };
    }
}