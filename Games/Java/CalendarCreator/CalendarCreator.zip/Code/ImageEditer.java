import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

public class ImageEditer extends JPanel {
    private JFileChooser chooser;
    private JFrame app;
    
    public ImageEditer(JFrame app) {
        this.app = app;
        setLayout(null);
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setSize(2000, 1000);
        setupChooser();
        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if(e.getButton() == MouseEvent.BUTTON1) openImage(e);
            }
        });
    }

    private void setupChooser() {
        Boolean old = UIManager.getBoolean("FileChooser.readOnly");
        UIManager.put("FileChooser.readOnly", Boolean.TRUE);
        chooser = new JFileChooser(".");
        UIManager.put("FileChooser.readOnly", old);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setFileFilter(imageFilter());
    }

    private FileFilter imageFilter() {
        return new FileFilter() {
            @Override
            public boolean accept(File f) {
                String fileName = f.getName();
                return f.isDirectory()
                    || fileName.endsWith(".jpeg")
                    || fileName.endsWith(".jpg")
                    || fileName.endsWith(".png");
            }

            @Override
            public String getDescription() {
                return "Images";
            }
        };
    }

    private void openImage(MouseEvent e) {
        int return_var = chooser.showOpenDialog(app);
        if(return_var == JFileChooser.APPROVE_OPTION) {
            try {
                BufferedImage in = ImageIO.read(chooser.getSelectedFile());
                BufferedImage updated_image = new BufferedImage(in.getWidth(), in.getHeight(), BufferedImage.TYPE_INT_ARGB);
                updated_image.createGraphics().drawImage(in, 0, 0, in.getWidth(), in.getHeight(), null);
                Token t = new Token(updated_image, e.getX(), e.getY(), this);
                add(t);
                setComponentZOrder(t, 0);
                repaint();
            } catch (IOException e1) {}
        }
    }
}