import java.io.File;

public class Start {
    public static void main(String[] args) {
        new File("Calendar").mkdir();
        new Display();
    }
}