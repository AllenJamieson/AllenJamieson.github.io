import java.io.File;

public class Start {
    public static void main(String[] args) {
        System.out.println("Making sure there is a folder to store the images...");
        new File("Calendar").mkdir();
        System.out.println("Beginning the program...");
        new Display();
    }
}