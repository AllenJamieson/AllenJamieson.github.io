import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Token extends JLabel {
    private BufferedImage image;

    public Token(BufferedImage image, int x, int y, JPanel panel) {
        this.image = image;
        setIcon(new ImageIcon(image));
        setBounds(x, y, image.getWidth(), image.getHeight());
        setFocusable(true);
        TokenEvent te = new TokenEvent(this, panel);
        addMouseListener(te);
        addMouseMotionListener(te);
        addMouseWheelListener(te);
    }

    public void scaleImage(int w, int h) {
        BufferedImage scaled_image = new BufferedImage(w, h, image.getType());
        scaled_image.createGraphics().drawImage(image, 0, 0, w, h, null);
        setIcon(new ImageIcon(scaled_image));
    }

    // https://stackoverflow.com/questions/9558981/flip-image-with-graphics2d
    public void flip() {
        BufferedImage flipped_image = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
        flipped_image.createGraphics().drawImage(image, image.getWidth(), 0, -image.getWidth(), image.getHeight(), null);
        image = flipped_image;
        scaleImage(getWidth(), getHeight());
    }

    public BufferedImage getImage() { return image; }

}