import java.awt.Component;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Token extends JLabel {
    private final JLabel SELF = this;

    private BufferedImage image;
    private JPanel panel;
    private int x_offset, y_offset;

    public Token(BufferedImage image, int x, int y, JPanel panel) {
        this.image = image;
        this.panel = panel;
        setIcon(new ImageIcon(image));
        setBounds(x, y, image.getWidth(), image.getHeight());
        setupListeners();
    }

    private void setupListeners() {
        MouseAdapter adapter = adapter();
        addMouseListener(adapter);
        addMouseMotionListener(adapter);
        addMouseWheelListener(adapter);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_DELETE) {
                    panel.grabFocus();
                    panel.remove(SELF);
                    panel.repaint();
                }
                if(e.getKeyCode() == KeyEvent.VK_F) flip();
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE) panel.grabFocus();
            }
        });
    }

    public boolean scaleImage(int w, int h) {
        System.out.println(w + " " + h);
        if(w > 20000 || h > 20000 || w < 25 || h < 25) return false;
        BufferedImage scaled_image = new BufferedImage(w, h, BufferedImage.SCALE_SMOOTH);
        scaled_image.createGraphics().drawImage(image, 0, 0, w, h, null);
        setIcon(new ImageIcon(scaled_image));
        setSize(w, h);
        return true;
    }

    // https://stackoverflow.com/questions/9558981/flip-image-with-graphics2d
    public void flip() {
        BufferedImage flipped_image = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
        flipped_image.createGraphics().drawImage(image, image.getWidth(), 0, -image.getWidth(), image.getHeight(), null);
        image = flipped_image;
        scaleImage(getWidth(), getHeight());
    }

    private MouseAdapter adapter() {
        return new MouseAdapter() { 
            @Override
            public void mousePressed(MouseEvent e) {
                grabFocus();
                int button = e.getButton();
                x_offset = e.getX();
                y_offset = e.getY();
                panel.setComponentZOrder(SELF, 0);

                if(button == MouseEvent.BUTTON3) {
                    Component[] items = panel.getComponents();
                    for (Component component : items)
                        if(!component.equals(SELF)) 
                            panel.setComponentZOrder(component, 0);
                }
                panel.repaint();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - x_offset - panel.getX(),
                    y = e.getYOnScreen() - y_offset - panel.getY();
                setLocation(x, y);
            }
            
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                if(isFocusOwner()) {
                    double scale = e.getWheelRotation() == 1 ? (9.0/10.0) : (10.0/9.0); // TODO update to desired scaling
                    int x = (int)(e.getXOnScreen() - (e.getX() * scale) - panel.getX()),
                        y = (int)(e.getYOnScreen() - (e.getY() * scale) - panel.getY()),
                        h = (int) (getHeight() * scale),
                        w = (int) (getWidth() * scale);
                    if(scaleImage(w, h)) setLocation(x, y);
                }
            }
        };
    }

    public BufferedImage getImage() { return image; }
    public JPanel getPanel() { return panel; }
}