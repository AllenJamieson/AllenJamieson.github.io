public enum Suit {
    CLUBS("\u2663"), DIAMONDS("\u2666"), HEARTS("\u2665"), SPADES("\u2660");

    private String unicode;
    private Suit(String unicode) {
        this.unicode = unicode;
    }

    public String getUnicode() { return unicode; }
}
