import java.util.ArrayList;
import java.util.Random;

public class Deck {
    private ArrayList<Card> deck;
    public Deck() {
        deck = new ArrayList<>();
        Random rand = new Random();
        ArrayList<Card> temp = new ArrayList<>();
        for (Suit suit : Suit.values()) {
            temp.add(new Card(suit, "A"));
            for (short face = 2; face <= 10; face++)
                temp.add(new Card(suit, "" + face));
            temp.add(new Card(suit, "J"));
            temp.add(new Card(suit, "Q"));
            temp.add(new Card(suit, "K"));
        }

        for (short d = 0; d < 52; d++)
            deck.add(temp.remove(rand.nextInt(temp.size())));
        deck.trimToSize();
        temp = null;
        rand = null;
    }

    public Card draw() { return isEmpty() ? null : deck.remove(0); }
    public boolean isEmpty() { return deck.isEmpty(); }
}