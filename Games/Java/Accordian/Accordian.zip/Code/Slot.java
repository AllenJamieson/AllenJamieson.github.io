import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;

public class Slot extends JLabel {
        private Card card;
        private short position;
        public Slot(Card c, Display d) {
            card = c;
            Slot s = this;
            setSize(100, 150);
            setOpaque(true);
            setBackground(Color.WHITE);
            setFont(new Font("Times New Roman", Font.ROMAN_BASELINE, 30));
            if(c.getSuit().equals(Suit.HEARTS) || c.getSuit().equals(Suit.DIAMONDS))
                setForeground(Color.RED);
            setText(c.toString());

            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    if(getBackground() == Color.LIGHT_GRAY) setBackground(Color.WHITE);
                    else setBackground(Color.LIGHT_GRAY);
                    d.move(s);
                }
            });
        }

        public void position(short size) { position = size; setLocation(size%13*110, size/13*160); }

        public Card getCard() { return card; }
        public short getPosition() { return position; }

        @Override
        public boolean equals(Object obj) {
            if(!(obj instanceof Slot)) return false;
            return card.equals(((Slot) obj).getCard());
        }
        
    }
