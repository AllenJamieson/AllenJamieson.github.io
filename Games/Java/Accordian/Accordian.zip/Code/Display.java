import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Display {

    private JFrame app;
    private JButton drawButton;
    private JPanel handPanel;
    private Deck deck;
    private ArrayList<Slot> hand;
    private short cardSize;
    private Slot slot1;
    
    public Display() {
        app = new JFrame("Accordian");
        drawButton = new JButton("Draw");
        handPanel = new JPanel();
        deck = new Deck();
        hand = new ArrayList<>();
        cardSize = 0;
        slot1 = null;
        Display dis = this;

        app.setLayout(null);
        app.setSize(1455, 750);
        
        drawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Card c = deck.draw();
                if(deck.isEmpty()) drawButton.setEnabled(false);
                if(c != null) {
                    Slot s = new Slot(c, dis);
                    s.position(cardSize++);
                    hand.add(s);
                    handPanel.add(s);
                    app.repaint();
                }
            }
        });
        
        drawButton.setBounds(700, 650, 100, 30);
        handPanel.setBounds(10, 10, 1445, 700);
        app.add(drawButton);
        app.add(handPanel);

        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    }

    public void move(Slot slotx) {
        if(slot1 == null) slot1 = slotx;
        else {
            short slot1Position = slot1.getPosition(), slot2Position = slotx.getPosition();
            if((slot1Position == slot2Position+1 || slot1Position == slot2Position+3) && slot1.equals(slotx)) {
                slot1.position(slot2Position);
                hand.set(slot2Position, slot1);
                hand.remove(slot1Position);
                for (short s = slot1Position; s < hand.size(); s++) hand.get(s).position(s);
                handPanel.removeAll();
                for (Slot slot : hand) handPanel.add(slot);
                cardSize--;
            }
            slot1.setBackground(Color.WHITE);
            slotx.setBackground(Color.WHITE);
            slot1 = null;
            app.repaint();
            if(deck.isEmpty() && hand.size() == 1) {
                JOptionPane.showMessageDialog(null, "Win", "Accordian", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        }
    }
}