public class Card {
    private String face;
    private Suit suit;

    public Card(Suit suit, String face) {
        this.face = face;
        this.suit = suit;
    }

    public String getFace() { return face; }
    public Suit getSuit() { return suit; }

    @Override
    public boolean equals(Object obj) {
        Card c = (Card) obj;
        return c.getSuit().equals(suit) || c.getFace().equals(face);
    }

    @Override
    public String toString() { return face + suit.getUnicode(); }
}
