import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Scanner;
import java.util.zip.Deflater;

// https:wiki.factorio.com/Blueprint_string_format
// https:www.geeksforgeeks.org/deflater-deflate-function-in-java-with-examples/
// https:www.baeldung.com/java-base64-encode-and-decode
// https:www.geeksforgeeks.org/how-to-copy-text-to-the-clipboard-in-java/
public class JSON_Encoder {
    private Scanner scan;
    private Deflater deflate;
    private String encode; 

    public JSON_Encoder() throws IOException {
        encode= "";
        System.out.println("Encoding the JSON for Factorio...");
        deflate = new Deflater(9);
        scan = new Scanner(new File("blueprint.json"));
        String line = scan.nextLine();
        deflate.setInput(line.getBytes("UTF-8"));
        deflate.finish();
        byte[] output = new byte[1000000000];
        int size = deflate.deflate(output);
        deflate.end();
        encode = "0" + Base64.getEncoder().encodeToString(Arrays.copyOf(output, size));
        System.out.println(size);
        Clipboard clip = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection s = new StringSelection(encode);
        clip.setContents(s, s);

    }

    public String getEncode() { return encode; }
}
