import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class ImageLoader {
    private long[][] data;
    private int[] colors_data;
    private boolean isGif;

    public ImageLoader(File file, int k) throws Exception {
        System.out.println("Extracting " + file.getName() + "...");
        colors_data = new int[k];
        // Gif splitter is not to be as there is a pattent on some forms or is a full on copy of anothers works
        if(file.getName().contains(".jpg") || file.getName().contains(".png") || file.getName().contains(".jpeg")) {
            isGif = false;
            System.out.println("Creating 2D pixel array of the image...");
            BufferedImage image = ImageIO.read(file);
            data = new long[image.getHeight()][image.getWidth()];
            for (short v = 0; v < data.length; v++)
                for (short h = 0; h < data[0].length; h++)
                    data[v][h] = image.getRGB(h, v);
        } else {
            isGif = true;
            System.out.println("Creating gif data...");
            File folder = file;
            if (!folder.isDirectory()) return;
            File[] files = folder.listFiles();
            BufferedImage[] images = new BufferedImage[files.length];
            for (int f = 0; f < images.length; f++) images[f] = ImageIO.read(files[f]);
            Lloyd k_cluster = new Lloyd();
            int width = images[0].getWidth(), height = images[0].getHeight();
            data = new long[height][width];

            System.out.println("Finding colors of individual images...");
            ArrayList<double[]> colors = new ArrayList<>();
            for (BufferedImage img : images) {
                k_cluster.clearData();
                ArrayList<double[]> img_colors = new ArrayList<>();
                for (short v = 0; v < height; v++) {
                    for (short h = 0; h < width; h++) {
                        int c = img.getRGB(h, v);
                        img_colors.add(new double[] { (c & 0x00ff0000) >> 16, (c & 0x0000ff00) >> 8, c & 0x000000ff });
                    }
                }
                img_colors.trimToSize();
                k_cluster.setInput(img_colors, k);
                double[][] color_list = k_cluster.getOutput();
                for (double[] color : color_list) colors.add(color);
            }

            System.out.println("Finding colors for all images...");
            k_cluster.clearData();
            k_cluster.setInput(colors, k);
            double[][] color_list = k_cluster.getOutput();
            for (short c = 0; c < k; c++)
                colors_data[c] = new Color((int) color_list[c][0], (int) color_list[c][1], (int) color_list[c][2]).getRGB();
            
            System.out.println("Setup the image data...");
            for (short img = 0; img < images.length; img++) {
                for (short v = 0; v < height; v++) {
                    for (short h = 0; h < width; h++) {
                        int c = images[img].getRGB(h, v), min = Integer.MAX_VALUE, val = -1;
                        data[v][h] <<= (k/2);
                        for (int co = 0; co < k; co++) {
                            double diff = Math.sqrt(Math.pow(c-colors_data[co], 2));

                            if(min > diff) {
                                min = (int)(diff + 0.5);
                                val = co;
                            }
                        }
                        images[img].setRGB(h, v, new Color(colors_data[val]).getRGB());
                        data[v][h] += val;
                    }
                }
                ImageIO.write(images[img], "png", new File("temp/" + img + ".png"));
            }
        }
        System.out.println("Extraction complete...");
    }

    public long[][] getData() { return data; }
    public int[] getColors_data() { return colors_data; }
    public boolean isGif() { return isGif; }
}
