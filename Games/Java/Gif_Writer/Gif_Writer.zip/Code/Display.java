import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.UIManager;

public class Display {
    private JFrame app;
    private JButton select;
    private JFileChooser fileChooser;

    public Display() {
        app = new JFrame();
        fileChooser = new JFileChooser();
        select = new JButton("Select");

        Boolean old = UIManager.getBoolean("FileChooser.readOnly");
        UIManager.put("FileChooser.readOnly", Boolean.TRUE);
        fileChooser = new JFileChooser(".");
        UIManager.put("FileChooser.readOnly", old);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

        select.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                int returnVar = fileChooser.showOpenDialog(app);
                if(returnVar == JFileChooser.APPROVE_OPTION) {
                    try {
                        new JSON_Writer(new ImageLoader(fileChooser.getSelectedFile(), 2));
                        new JSON_Encoder();
                    } catch (Exception e1) { e1.printStackTrace(); }
                }
            }
            
        });
        
        select.setBounds(5, 5, 100, 30);
        app.add(select);
        app.setSize(500, 500);
        app.setLayout(null);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    }

}
