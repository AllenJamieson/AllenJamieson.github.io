import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class JSON_Writer {
    private FileWriter writer;
    private long[][] data;
    private boolean isGif;
    private int[] colors;
    private final String[] ITEMS = {
        "wooden-chest", "iron-chest", "steel-chest", "storage-tank",
        "transport-belt", "fast-transport-belt", "express-transport-belt", "underground-belt", "fast-underground-belt", "express-underground-belt", "splitter", "fast-splitter", "express-splitter",
        "burner-inserter", "inserter", "long-handed-inserter", "fast-inserter", "bulk-inserter",
        "small-electric-pole", "medium-electric-pole", "big-electric-pole", "substation", "pipe", "pipe-to-ground", "pump",
        "rail", "train-stop", "rail-signal", "rail-chain-signal", "locomotive", "cargo-wagon", "fluid-wagon", "artillery-wagon",
        "car", "tank", "spidertron",
        "logistic-robot", "construction-robot", "active-provider-chest", "passive-provider-chest", "storage-chest", "buffer-chest", "requester-chest", "roboport",
        "small-lamp", "arithmetic-combinator", "decider-combinator", "selector-combinator", "constant-combinator", "power-switch", "programmable-speaker", "display-panel",
        "stone-brick", "concrete", "hazard-concrete", "refined-concrete", "refined-hazard-concrete", "landfill", "cliff-explosives",

        "repair-pack", "blueprint", "deconstruction-planner", "upgrade-planner", "blueprint-book",
        "boiler", "steam-engine", "solar-panel", "accumulator", "nuclear-reactor", "heat-pipe", "heat-exchanger", "steam-turbine",
        "burner-mining-drill", "electric-mining-drill", "offshore-pump", "pumpjack",
        "stone-furnace", "steel-furnace", "electric-furnace",
        "assembling-machine-1", "assembling-machine-2", "assembling-machine-3", "oil-refinery", "chemical-plant", "centrifuge", "lab",
        "beacon", "speed-module", "speed-module-2", "speed-module-3", "efficiency-module", "efficiency-module-2", "efficiency-module-3", "productivity-module", "productivity-module-2", "productivity-module-3",
        "rocket-silo", "cargo-landing-pad", "satellite",

        // Contains recipe
        "wood", "coal", "stone", "iron-ore", "copper-ore", "uranium-ore", "raw-fish",
        "iron-plate", "copper-plate", "steel-plate", "solid-fuel", "plastic-bar", "sulfur", "battery", "explosives",
        "water-barrel", "crude-oil-barrel", "petroleum-gas-barrel", "light-oil-barrel", "heavy-oil-barrel", "lubricant-barrel", "sulfuric-acid-barrel",
        // Contains recipe
        // Contains recipe
        "iron-gear-wheel", "iron-stick", "copper-cable", "barrel", "electronic-circuit", "advanced-circuit", "processing-unit", "engine-unit", "electric-engine-unit", "flying-robot-frame",
        "low-density-structure", "rocket-fuel", "rocket-part",
        "uranium-235", "uranium-238", "uranium-fuel-cell", "depleted-uranium-fuel-cell", "nuclear-fuel", // Some Contain recipe
        "automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack", "space-science-pack",

        "pistol", "submachine-gun", "shotgun", "combat-shotgun", "rocket-launcher", "flamethrower",
        "firearm-magazine", "piercing-rounds-magazine", "uranium-rounds-magazine", "shotgun-shell", "piercing-shotgun-shell", "cannon-shell", "explosive-cannon-shell", "uranium-cannon-shell", "explosive-uranium-cannon-shell", "artillery-shell",
        "rocket", "explosive-rocket", "atomic-bomb", "flamethrower-ammo",
        "grenade", "cluster-grenade", "poison-capsule", "slowdown-capsule", "defender-capsule", "distractor-capsule", "destroyer-capsule", // Some Contains entity
        "light-armor", "heavy-armor", "modular-armor", "power-armor", "power-armor-mk2",
        "solar-panel-equipment", "fission-reactor-equipment", "battery-equipment", "battery-mk2-equipment",
        "belt-immunity-equipment","exoskeleton-equipment", "personal-roboport-equipment", "personal-roboport-mk2-equipment", "night-vision-equipment",
        "energy-shield-equipment", "energy-shield-mk2-equipment", "personal-laser-defense-equipment", "discharge-defense-equipment",
        "stone-wall", "gate", "radar", "land-mine",
        "gun-turret", "laser-turret", "flamethrower-turret", "artillery-turret",
        
        // Contains fluid

        // Skip Signals

        // Contains entity

        // Contains entity

        "copper-wire", "green-wire", "red-wire", "spidertron-remote", "discharge-defense-remote", "artillery-targeting-remote"
        // Contains entity
    };

    public JSON_Writer(ImageLoader loader) throws IOException {
        writer = new FileWriter("blueprint.json");
        data = loader.getData();
        isGif = loader.isGif();
        colors = loader.getColors_data();
        //negativeWriter();
        //lampWriter();
        startWriting();
        writeData();
        endWriting();
    }

    private void lampWriter() throws IOException {
        System.out.println("Creating 1 vertical strip of the screen...");
        startLampWriter();
        lamp();
        wire();
        endLampWriter();
    }

    private void negativeWriter() throws IOException {
        System.out.println("Create the negative 1s...");
        StringBuilder builder = new StringBuilder();
        String start    = "{"
                        + "\"blueprint\":{"
                        + "\"snap-to-grid\":{"
                        + "\"x\":1,"
                        + "\"y\":1"
                        + "},"
                        + "\"icons\":["
                        + "{"
                        + "\"signal\":{"
                        + "\"name\":\"small-lamp\""
                        + "},"
                        + "\"index\":1"
                        + "}"
                        + "],"
                        + "\"entities\":["
                        + "{"
                        + "\"entity_number\":1,"
                        + "\"name\":\"constant-combinator\","
                        + "\"position\":{"
                        + "\"x\":0.5,"
                        + "\"y\":0.5"
                        + "},"
                        + "\"control_behavior\":{"
                        + "\"sections\":{"
                        + "\"sections\":["
                        + "{"
                        + "\"index\":1,"
                        + "\"filters\":[";
            builder.append(start);
            for (short v = 0; v < ITEMS.length; v++)
                builder.append("{\"index\":"+ (v+1) + ",\"name\":\"" + ITEMS[v] + "\",\"quality\":\"normal\",\"comparator\":\"=\",\"count\":-1},");
            builder.deleteCharAt(builder.length()-1);
            builder.append("]}]}}}");
            String end  = "],"
                        +"\"item\": \"blueprint\","
                        + "\"version\":562949955518464"
                        + "}}";
            builder.append(end);
            writer.append(builder.toString());
            writer.close();
    }

    private void startLampWriter() throws IOException {
        String start    = "{"
                        + "\"blueprint\":{"
                        + "\"snap-to-grid\":{"
                        + "\"x\":1,"
                        + "\"y\":" + ITEMS.length
                        + "},"
                        + "\"icons\":["
                        + "{"
                        + "\"signal\":{"
                        + "\"name\":\"small-lamp\""
                        + "},"
                        + "\"index\":1"
                        + "}"
                        + "],"
                        + "\"entities\":[";
        writer.append(start);
    }

    private void lamp() throws IOException {
        StringBuilder builder = new StringBuilder();
        for (short num = 0; num < ITEMS.length; num++) {
            String  midSection  = "{"
                                + "\"entity_number\":" + (num+1) + ","
                                + "\"name\":\"small-lamp\","
                                + "\"position\":{"
                                + "\"x\":0.5,"
                                + "\"y\":" + (num+0.5)
                                + "},"
                                + "\"control_behavior\":{"
                                + "\"use_colors\":true,"
                                + "\"rgb_signal\":{"
                                + "\"name\": \"" + ITEMS[num] + "\""
                                + "},"
                                + "\"color_mode\":2"
                                + "},"
                                + "\"always_on\":true"
                                + "},";
            builder.append(midSection);
        }
        builder.deleteCharAt(builder.length()-1);
        writer.append(builder.toString());
    }

    private void wire() throws IOException {
        StringBuilder builder = new StringBuilder();
        builder.append("],\"wires\":[");
        for (short num = 0; num < ITEMS.length-1; num++)
            builder.append("[" + (num+1) + ",1," + (num+2) + ",1],");
        builder.deleteCharAt(builder.length()-1);
        writer.append(builder.toString());
    }

    private void endLampWriter() throws IOException {
        String end  = "],"
                    +"\"item\": \"blueprint\","
                    + "\"version\":562949955518464"
                    + "}}";
        writer.append(end);
        writer.close();
    }

    private void startWriting() throws IOException {
        System.out.println("Creating the JSON equivilant data...");
        String start    = "{"
                        + "\"blueprint\":{"
                        + "\"snap-to-grid\":{"
                        + "\"x\":" + (isGif?data[0].length+1:data[0].length) + ","
                        + "\"y\":1"
                        + "},"
                        + "\"icons\":["
                        + "{"
                        + "\"signal\":{"
                        + "\"name\":\"constant-combinator\""
                        + "},"
                        + "\"index\":1"
                        + "}"
                        + "],"
                        + "\"entities\":[";
        writer.append(start);
    }

    private void writeData() throws IOException {
        StringBuilder builder = new StringBuilder();
        for (short h = 0; h < data[0].length; h++) {
            String midSection   = "{"
                                + "\"entity_number\":" + (h+1) + ","
                                + "\"name\":\"constant-combinator\","
                                + "\"position\":{"
                                + "\"x\":" + (h+0.5) + ","
                                + "\"y\":0.5"
                                + "},"
                                + "\"control_behavior\":{"
                                + "\"sections\":{"
                                + "\"sections\":["
                                + "{"
                                + "\"index\":1,"
                                + "\"filters\":[";
            builder.append(midSection);
            for (short v = 0; v < data.length; v++) {
                if(v < ITEMS.length)
                    builder.append("{\"index\":"+ (v+1) + ",\"name\":\"" + ITEMS[v] + "\",\"quality\":\"normal\",\"comparator\":\"=\",\"count\":" + data[v][h] + "},");
                else break;
            }
            builder.deleteCharAt(builder.length()-1);
            builder.append("]}]}}},");
        }
        if(isGif) {
            System.out.println("More to be added");
            System.out.println(Arrays.toString(colors));
            String midSection   = "{"
                                + "\"entity_number\":" + (data[0].length+1) + ","
                                + "\"name\":\"constant-combinator\","
                                + "\"position\":{"
                                + "\"x\":" + (data[0].length + 0.5) + ","
                                + "\"y\":0.5"
                                + "},"
                                + "\"control_behavior\":{"
                                + "\"sections\":{"
                                + "\"sections\":["
                                + "{"
                                + "\"index\":1,"
                                + "\"filters\":[";
            builder.append(midSection);
            for (short i = 0; i < colors.length; i++)
                builder.append("{\"index\":" + (i+1) + ",\"type\":\"virtual\",\"name\":\"signal-" + i + "\",\"quality\":\"normal\",\"comparator\":\"=\",\"count\":" + colors[i] + "},");
            builder.deleteCharAt(builder.length()-1);
            builder.append("]}]}}},");
        }
        builder.deleteCharAt(builder.length()-1);
        writer.append(builder.toString());
    }

    private void endWriting() throws IOException {
        String end  = "],"
                    +"\"item\": \"blueprint\","
                    + "\"version\":562949955518464"
                    + "}}";
        writer.append(end);
        writer.close();
    }
}