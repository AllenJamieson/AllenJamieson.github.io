import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Board extends JPanel {
    private final short HEIGHT = 3, WIDTH = 5;
    private final short PADDING = 5;
    private short size;
    private final Token[] TOKENS = {
        new Token("g.png"),
        new Token("l.png"),
        new Token("a.png"),
        new Token("t.png"),
        new Token("b.png"),
        new Token("i.png"),
        new Token("pride.png")
    };

    private Random rand;
    private JLabel[][] tokenBoard;
    private short[][] board;
    private short count;

    public Board() {
        board = new short[HEIGHT][WIDTH];
        tokenBoard = new JLabel[HEIGHT][WIDTH];
        rand = new Random();
        size = TOKENS[0].getTokenSize();
        setSize((size + PADDING) * WIDTH - PADDING, (size + PADDING) * HEIGHT - PADDING);
        setLayout(null);
        for (short v = 0; v < tokenBoard.length; v++) {
            for (short h = 0; h < tokenBoard[0].length; h++) {
                Token t = TOKENS[rand.nextInt(TOKENS.length)].copy();
                setLocation(t, v, h, 0);
                tokenBoard[v][h] = t;
                add(t);
            }
        }
    }

    public short spin(int amount, JButton btn, JLabel win, JLabel balanceLabel, int currentAmount) {
        short fillerHeight = 25;
        JLabel[][] filler = new JLabel[fillerHeight][WIDTH];
        JLabel[][] newBoard = new JLabel[HEIGHT][WIDTH];

        for (short v = 0; v < fillerHeight; v++) { // Filler
            for (short h = 0; h < WIDTH; h++) {
                Token t = TOKENS[rand.nextInt(TOKENS.length)].copy();
                setLocation(t, (short) -v, h, size + PADDING);
                filler[v][h] = t;
                add(t);
            }
        }
        for (short v = 0; v < HEIGHT; v++) {
            for (short h = 0; h < WIDTH; h++) {
                short prob = (short)rand.nextInt(100); // Reduce the probability of the last 2 tokens
                int num;
                if(prob < 20) num = TOKENS.length - rand.nextInt(2)-1;
                else num = rand.nextInt(TOKENS.length-2);
                board[v][h] = (short) num;
                Token t = TOKENS[num].copy();
                setLocation(t, v, h, (size + PADDING) * fillerHeight + getHeight() + PADDING);
                newBoard[v][h] = t;
                add(t);
            }
        }
        short solve = solve(amount);
        animate(filler, newBoard, solve, btn, win, balanceLabel, currentAmount);
        displayBoard();
        return solve;
    }

    private void animate(JLabel[][] filler, JLabel[][] newBoard, short solve, JButton btn, JLabel win, JLabel balanceLabel, int currentAmount) {
        for (short h = 0; h < WIDTH; h++) {
            Timer timer = new Timer(1, null);
            short a = h;
            timer.addActionListener(new ActionListener() {
                short h = a;
                @Override
                public void actionPerformed(ActionEvent e) {
                    move(tokenBoard, h);
                    move(filler, h);
                    move(newBoard, h);
                    if(newBoard[0][h].getY() > 0) {
                        for (short v = 0; v < HEIGHT; v++)
                            setLocation(newBoard[v][h], v, h, 0);
                        timer.stop();
                        if(h == WIDTH-1) {
                            tokenBoard = newBoard;
                            balanceLabel.setText("Balance: " + (solve + currentAmount));
                            win.setVisible(true);
                            btn.setEnabled(true);
                        }
                    }
                }
            });
            timer.setInitialDelay(h*500);
            timer.start();
        }
    }

    private short solve(int bet) {
        count = 0;
        for (short v = 0; v < HEIGHT; v++) search(v,0, board[v][0]);
        return (short) (bet*count);
    }

    private void search(int v, int h, short val) {
        short wild = 5;
        if(v < 0 || v >= HEIGHT || h >= WIDTH) return;
        if(val == wild && board[v][h] != wild) val = board[v][h]; // Wild
        if(board[v][h] != val && board[v][h] != wild) return;
        if(h == WIDTH-1) {
            System.out.println(val);
            count += (val == 6 ? 3 : 1);
        } // Bonus
        search(v-1, h+1, val);
        search(v, h+1, val);
        search(v+1, h+1, val);
    }

    private void setLocation(JLabel t, short v, short h, int offset) {
        t.setLocation((size + PADDING) * h, (size + PADDING) * v - offset);
    }

    private void move(JLabel[][] board, short h) {
        for (JLabel[] v : board) {
            JLabel token = v[h];
            token.setLocation(token.getX(), token.getY() + 8);
            if(token.getY() > getHeight()) remove(token);
        }
    }

    private void displayBoard() {
        for (short[] v : board) {
            for (short h : v) System.out.print(h + "\t");
            System.out.println();
        }
    }
}