import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Slots {
    private final short STEP_AMOUNT = 10;

    private JFrame app;
    private JLabel balanceLabel, winLabel, betLabel;
    private JSpinner betAmount;
    private JButton spinButton;
    private Board board;

    private int currentAmount = 1000;

    public Slots() {
        initialize();

        spinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Spinning:");
                winLabel.setVisible(false);
                spinButton.setEnabled(false);
                int bet = (int) betAmount.getValue();
                currentAmount -= bet;
                setBalance();
                short winAmount = board.spin(bet, spinButton, winLabel, balanceLabel, currentAmount);
                setWinAmount(winAmount);
                currentAmount += winAmount;
                while (bet > currentAmount) bet -= STEP_AMOUNT;
                if(bet <= 0) {
                    spinButton.setEnabled(false);
                    betAmount.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Out of money", "Slots", JOptionPane.WARNING_MESSAGE);
                    System.exit(0);
                }                
                betAmount.setValue(bet);
            }
        });

        betAmount.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSpinner spin = (JSpinner)e.getSource();
                if((int)spin.getValue() > currentAmount)
                    spin.setValue(currentAmount);
            }
        });

        app.setLayout(null);
        position();
        app.setResizable(false);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    }

    private void initialize() {
        app = new JFrame("Slots");
        balanceLabel = new JLabel();
        winLabel = new JLabel();
        betLabel = new JLabel("Bet");
        betAmount = new JSpinner(new SpinnerNumberModel(10, 10, 100, STEP_AMOUNT));
        spinButton = new JButton("Spin");
        board = new Board();
        app.setIconImage(new ImageIcon(getClass().getResource("Tokens/pride.png")).getImage());
        // https://stackoverflow.com/questions/2902101/how-to-set-jspinner-as-non-editable
        ((DefaultEditor)betAmount.getEditor()).getTextField().setEditable(false);
        setBalance();
        setWinAmount((short)0);
    }

    private void position() {
        int boardWidth = board.getWidth();
        app.setSize(boardWidth + 25, board.getHeight() + 150);
        balanceLabel.setBounds(5, 5, 200, 30);
        winLabel.setBounds(boardWidth/2 -50, 5, 100, 30);
        betLabel.setBounds(boardWidth - 75, 5, 100, 30);
        spinButton.setBounds(boardWidth/2 -50, board.getHeight() + 60, 100, 30);
        betAmount.setBounds(boardWidth - 45, 5, 50, 30);
        board.setLocation(5, 50);
        app.add(balanceLabel);
        app.add(winLabel);
        app.add(betLabel);
        app.add(spinButton);
        app.add(betAmount);
        app.add(board);
    }

    private void setBalance() { balanceLabel.setText("Balance: " + currentAmount); }
    private void setWinAmount(short amount) { winLabel.setText("Win: " + amount);}
}