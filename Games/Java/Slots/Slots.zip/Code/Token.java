import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Token extends JLabel {
    private final short SIZE = 64;

    private String imagePath;
    
    public Token(String imagePath) {
        this.imagePath = imagePath;
        setSize(SIZE, SIZE);
        setHorizontalAlignment(CENTER);
        setVerticalAlignment(CENTER);
        // https://www.daniweb.com/programming/software-development/threads/21906/accessing-images-in-jar-file
        setIcon(new ImageIcon(getClass().getResource("Tokens/" + imagePath)));
    }

    public Token copy() { return new Token(this.imagePath); }
    
    public short getTokenSize() { return SIZE; }
}