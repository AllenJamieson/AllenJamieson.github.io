import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Scanner;
import java.util.zip.Deflater;

public class BlueprintWriter {
    private FileWriter writer;
    protected final String[] ITEMS = {
        "wooden-chest", "iron-chest", "steel-chest", "storage-tank",
        "transport-belt", "fast-transport-belt", "express-transport-belt", "underground-belt", "fast-underground-belt", "express-underground-belt", "splitter", "fast-splitter", "express-splitter",
        "burner-inserter", "inserter", "long-handed-inserter", "fast-inserter", "bulk-inserter",
        "small-electric-pole", "medium-electric-pole", "big-electric-pole", "substation", "pipe", "pipe-to-ground", "pump",
        "rail", "train-stop", "rail-signal", "rail-chain-signal", "locomotive", "cargo-wagon", "fluid-wagon", "artillery-wagon",
        "car", "tank", "spidertron",
        "logistic-robot", "construction-robot", "active-provider-chest", "passive-provider-chest", "storage-chest", "buffer-chest", "requester-chest", "roboport",
        "small-lamp", "arithmetic-combinator", "decider-combinator", "selector-combinator", "constant-combinator", "power-switch", "programmable-speaker", "display-panel",
        "stone-brick", "concrete", "hazard-concrete", "refined-concrete", "refined-hazard-concrete", "landfill", "cliff-explosives",

        "repair-pack", "blueprint", "deconstruction-planner", "upgrade-planner", "blueprint-book",
        "boiler", "steam-engine", "solar-panel", "accumulator", "nuclear-reactor", "heat-pipe", "heat-exchanger", "steam-turbine",
        "burner-mining-drill", "electric-mining-drill", "offshore-pump", "pumpjack",
        "stone-furnace", "steel-furnace", "electric-furnace",
        "assembling-machine-1", "assembling-machine-2", "assembling-machine-3", "oil-refinery", "chemical-plant", "centrifuge", "lab",
        "beacon", "speed-module", "speed-module-2", "speed-module-3", "efficiency-module", "efficiency-module-2", "efficiency-module-3", "productivity-module", "productivity-module-2", "productivity-module-3",
        "rocket-silo", "cargo-landing-pad", "satellite",

        // Contains recipe
        "wood", "coal", "stone", "iron-ore", "copper-ore", "uranium-ore", "raw-fish",
        "iron-plate", "copper-plate", "steel-plate", "solid-fuel", "plastic-bar", "sulfur", "battery", "explosives",
        "water-barrel", "crude-oil-barrel", "petroleum-gas-barrel", "light-oil-barrel", "heavy-oil-barrel", "lubricant-barrel", "sulfuric-acid-barrel",
        // Contains recipe
        // Contains recipe
        "iron-gear-wheel", "iron-stick", "copper-cable", "barrel", "electronic-circuit", "advanced-circuit", "processing-unit", "engine-unit", "electric-engine-unit", "flying-robot-frame",
        "low-density-structure", "rocket-fuel", "rocket-part",
        "uranium-235", "uranium-238", "uranium-fuel-cell", "depleted-uranium-fuel-cell", "nuclear-fuel", // Some Contain recipe
        "automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack", "space-science-pack",

        "pistol", "submachine-gun", "shotgun", "combat-shotgun", "rocket-launcher", "flamethrower",
        "firearm-magazine", "piercing-rounds-magazine", "uranium-rounds-magazine", "shotgun-shell", "piercing-shotgun-shell", "cannon-shell", "explosive-cannon-shell", "uranium-cannon-shell", "explosive-uranium-cannon-shell", "artillery-shell",
        "rocket", "explosive-rocket", "atomic-bomb", "flamethrower-ammo",
        "grenade", "cluster-grenade", "poison-capsule", "slowdown-capsule", "defender-capsule", "distractor-capsule", "destroyer-capsule", // Some Contains entity
        "light-armor", "heavy-armor", "modular-armor", "power-armor", "power-armor-mk2",
        "solar-panel-equipment", "fission-reactor-equipment", "battery-equipment", "battery-mk2-equipment",
        "belt-immunity-equipment","exoskeleton-equipment", "personal-roboport-equipment", "personal-roboport-mk2-equipment", "night-vision-equipment",
        "energy-shield-equipment", "energy-shield-mk2-equipment", "personal-laser-defense-equipment", "discharge-defense-equipment",
        "stone-wall", "gate", "radar", "land-mine",
        "gun-turret", "laser-turret", "flamethrower-turret", "artillery-turret",
        
        // Contains fluid

        // Skip Signals

        // Contains entity

        // Contains entity

        "copper-wire", "green-wire", "red-wire", "spidertron-remote", "discharge-defense-remote", "artillery-targeting-remote"
        // Contains entity
    };

    private String lamp() {
        StringBuilder builder = new StringBuilder();
        for (short num = 0; num < ITEMS.length; num++) {
            String  midSection  = "{"
                                + "\"entity_number\":" + (num+1) + ","
                                + "\"name\":\"small-lamp\","
                                + "\"position\":{"
                                + "\"x\":0.5,"
                                + "\"y\":" + (num+0.5)
                                + "},"
                                + "\"control_behavior\":{"
                                + "\"use_colors\":true,"
                                + "\"rgb_signal\":{"
                                + "\"name\": \"" + ITEMS[num] + "\""
                                + "},"
                                + "\"color_mode\":2"
                                + "},"
                                + "\"always_on\":true"
                                + "},";
            builder.append(midSection);
        }
        builder.deleteCharAt(builder.length()-1);
        return builder.toString();
    }

    private String wire() {
        StringBuilder builder = new StringBuilder();
        builder.append("],\"wires\":[");
        for (short num = 0; num < ITEMS.length-1; num++)
            builder.append("[" + (num+1) + ",1," + (num+2) + ",1],");
        builder.deleteCharAt(builder.length()-1);
        return builder.toString();
    }

    public void writeData(long[][] data) throws IOException {
        System.out.println("Creating the JSON equivilant data...");
        writer = new FileWriter("blueprint.json");
        StringBuilder builder = new StringBuilder();
        String start    = "{"
                        + "\"blueprint\":{"
                        + "\"snap-to-grid\":{"
                        + "\"x\":" + data[0].length + ","
                        + "\"y\":1"
                        + "},"
                        + "\"icons\":["
                        + "{"
                        + "\"signal\":{"
                        + "\"name\":\"constant-combinator\""
                        + "},"
                        + "\"index\":1"
                        + "}"
                        + "],"
                        + "\"entities\":[";
        builder.append(start);
        for (short h = 0; h < data[0].length; h++) {
            String midSection   = "{"
                                + "\"entity_number\":" + (h+1) + ","
                                + "\"name\":\"constant-combinator\","
                                + "\"position\":{"
                                + "\"x\":" + (h+0.5) + ","
                                + "\"y\":0.5"
                                + "},"
                                + "\"control_behavior\":{"
                                + "\"sections\":{"
                                + "\"sections\":["
                                + "{"
                                + "\"index\":1,"
                                + "\"filters\":[";
            builder.append(midSection);
            for (short v = 0; v < data.length; v++) {
                if(v < ITEMS.length)
                    builder.append("{\"index\":"+ (v+1) + ",\"name\":\"" + ITEMS[v] + "\",\"quality\":\"normal\",\"comparator\":\"=\",\"count\":" + data[v][h] + "},");
                else break;
            }
            builder.deleteCharAt(builder.length()-1);
            builder.append("]}]}}},");
        }
        builder.deleteCharAt(builder.length()-1);
        String end  = "],"
                    +"\"item\": \"blueprint\","
                    + "\"version\":562949955518464"
                    + "}}";
        builder.append(end);
        writer.append(builder.toString());
        writer.close();
    }

    public void writeLamps() throws IOException {
        writer = new FileWriter("blueprint.json");
        StringBuilder builder = new StringBuilder();
        String start    = "{"
                        + "\"blueprint\":{"
                        + "\"snap-to-grid\":{"
                        + "\"x\":1,"
                        + "\"y\":" + ITEMS.length
                        + "},"
                        + "\"icons\":["
                        + "{"
                        + "\"signal\":{"
                        + "\"name\":\"small-lamp\""
                        + "},"
                        + "\"index\":1"
                        + "}"
                        + "],"
                        + "\"entities\":[";
        builder.append(start);
        builder.append(lamp());
        builder.append(wire());

        String end  = "],"
                    +"\"item\": \"blueprint\","
                    + "\"version\":562949955518464"
                    + "}}";
        builder.append(end);
        writer.append(builder.toString());
        writer.close();
    }

    // https:wiki.factorio.com/Blueprint_string_format
    // https:www.geeksforgeeks.org/deflater-deflate-function-in-java-with-examples/
    // https:www.baeldung.com/java-base64-encode-and-decode
    // https:www.geeksforgeeks.org/how-to-copy-text-to-the-clipboard-in-java/
    public void encode() throws IOException {
        System.out.println("Encoding the JSON for Factorio...");
        Deflater deflate = new Deflater(9);
        Scanner scan = new Scanner(new File("blueprint.json"));
        String line = scan.nextLine();
        deflate.setInput(line.getBytes("UTF-8"));
        deflate.finish();
        byte[] output = new byte[1000000000];
        int size = deflate.deflate(output);
        deflate.end();
        String encode = "0" + Base64.getEncoder().encodeToString(Arrays.copyOf(output, size));
        System.out.println(size);
        Clipboard clip = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection s = new StringSelection(encode);
        clip.setContents(s, s);
        scan.close();
    }
}