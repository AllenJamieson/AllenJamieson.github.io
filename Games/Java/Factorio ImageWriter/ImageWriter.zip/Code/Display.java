import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Display {
    private JFrame app;
    private JButton select;
    private JButton createLamps;
    private JFileChooser fileChooser;
    private JCheckBox scaleCheckBox;
    private JLabel blueprintLabel;
    private BlueprintWriter writer;

    public Display() throws IOException {
        writer = new BlueprintWriter();
        app = new JFrame("Image to Factorio");
        fileChooser = new JFileChooser();
        select = new JButton("Select");
        createLamps = new JButton("Create Lamps");
        scaleCheckBox = new JCheckBox("Scale");
        scaleCheckBox.setSelected(true);
        blueprintLabel = new JLabel("Select an image");
        setupFileChooser();

        select.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int returnVar = fileChooser.showOpenDialog(app);
                if(returnVar == JFileChooser.APPROVE_OPTION) {
                    System.out.println("Extracting image...");
                    try {
                        BufferedImage image = ImageIO.read(fileChooser.getSelectedFile());
                        if(scaleCheckBox.isSelected()) {
                            int max_height = writer.ITEMS.length, scale = 1, img_height = image.getHeight();
                            while (img_height/scale > max_height) scale++;
                            BufferedImage scaled = new BufferedImage(image.getWidth()/scale, image.getHeight()/scale, BufferedImage.SCALE_SMOOTH);
                            scaled.getGraphics().drawImage(image, 0, 0, scaled.getWidth(), scaled.getHeight(), null);
                            image = scaled;
                        }
                        long[][] data = new long[image.getHeight()][image.getWidth()];
                        for (short v = 0; v < data.length; v++)
                            for (short h = 0; h < data[0].length; h++)
                                data[v][h] = image.getRGB(h, v);
                        System.out.println("Extraction complete...");
                        writer.writeData(data);
                        writer.encode();
                        blueprintLabel.setText(fileChooser.getSelectedFile().getName() + " Created and Copied");
                    } catch (Exception e1) { blueprintLabel.setText("Issue creating the image"); }
                }
            }
            
        });
        
        createLamps.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    writer.writeLamps();
                    writer.encode();
                    blueprintLabel.setText("Lamps Created Successfully");
                } catch (IOException e1) { blueprintLabel.setText("Issue creating the lamps");}
            }
        });
        select.setBounds(5, 5, 100, 30);
        scaleCheckBox.setBounds(150, 5, 100, 30);
        createLamps.setBounds(250, 5, 150, 30);
        blueprintLabel.setBounds(5, 50, 450, 30);
        app.add(select);
        app.add(scaleCheckBox);
        app.add(createLamps);
        app.add(blueprintLabel);

        app.setSize(500, 200);
        app.setLayout(null);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    }

    private void setupFileChooser() {
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images", "jpg", "png", "jpeg");
        Boolean old = UIManager.getBoolean("FileChooser.readOnly");
        UIManager.put("FileChooser.readOnly", Boolean.TRUE);
        fileChooser = new JFileChooser(".");
        UIManager.put("FileChooser.readOnly", old);
        fileChooser.setFileFilter(filter);
    }

}
