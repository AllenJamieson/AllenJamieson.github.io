import java.io.IOException;

public class Start {
    public static void main(String[] args) throws IOException {
        new Display();
    }
}