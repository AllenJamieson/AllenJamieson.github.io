import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Puzzle {
    private JFrame app;
    private JLabel completeImage, widthLabel, heightLabel;
    private JTextField xField, yField;
    private JButton openButton, shuffleButton, close;
    private ImageSetup imageData;
    private Board board;

    public Puzzle() {
        initialize();
        app.setLayout(null);
        app.setUndecorated(true);
        app.getContentPane().setBackground(Color.BLACK);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        actions();
        setupComponents();
        app.setVisible(true);
    }

    private void shuffle() {
        try {
            System.out.println("\nImage splitting");
            int subX = Integer.parseInt(xField.getText()),
                subY = Integer.parseInt(yField.getText());
            if(imageData.isDoable(subX, subY)) {
                imageData.subdivideImage(subX, subY);
                if(board.boardSetup(imageData.getSegmentedImage(), app))
                    showHide(false);
            } else System.out.println("Too many subdivisions");
        } catch (NumberFormatException nfe) { System.out.println("This is not a number"); }
    }

    private void actions() {
        app.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    if(completeImage.isVisible()) System.exit(0);
                    showHide(true);
                    board.removeAll();
                    app.repaint();
                }
                if(e.getKeyCode() == KeyEvent.VK_ENTER) shuffle();
            }
        });

        xField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE) System.exit(0);
                if(e.getKeyCode() == KeyEvent.VK_ENTER) shuffle();
            }
        });

        yField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE) System.exit(0);
                if(e.getKeyCode() == KeyEvent.VK_ENTER) shuffle();
            }
        });

        openButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                imageData.load();
                if(imageData.getImage() != null) {
                    completeImage.setIcon(new ImageIcon(imageData.getImage()));
                    shuffleButton.setEnabled(true);
                    xField.setEditable(true);
                    yField.setEditable(true);
                } else System.out.println("No image found");
            }
        });

        shuffleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { shuffle(); }
        });

        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { System.exit(0); }
        });
    }

    private void showHide(boolean visible) {
        close.setVisible(visible);
        openButton.setVisible(visible);
        shuffleButton.setVisible(visible);
        xField.setVisible(visible);
        yField.setVisible(visible);
        completeImage.setVisible(visible);
        widthLabel.setVisible(visible);
        heightLabel.setVisible(visible);
        xField.setFocusable(visible);
        yField.setFocusable(visible);
        app.requestFocus();
    }
    
    private void initialize() {
        app = new JFrame("Puzzle");
        completeImage = new JLabel("", null, JLabel.CENTER);
        widthLabel = new JLabel("Width Subdivision:");
        heightLabel = new JLabel("Height Subdivision:");
        xField = new JTextField();
        yField = new JTextField();
        openButton = new JButton("Get Image");
        shuffleButton = new JButton("Shuffle");
        close = new JButton("X");
        imageData = new ImageSetup(app);
        board = new Board();
    }

    private void setupComponents() {
        app.setSize(Toolkit.getDefaultToolkit().getScreenSize());
        short y1 = 5, y2 = 35, text_height = 20;
        completeImage.setBounds(0, 60, app.getWidth(), app.getHeight() - 60);
        close.setBounds(app.getWidth() - 55, 5, 50, 50);
        xField.setBounds(250, y1, 50, text_height);
        yField.setBounds(250, y2, 50, text_height);
        openButton.setBounds(5, y1, 100, text_height);
        shuffleButton.setBounds(5, y2, 100, text_height);
        widthLabel.setBounds(120, y1, 200, text_height);
        heightLabel.setBounds(120, y2, 200, text_height);

        xField.setEditable(false);
        yField.setEditable(false);
        shuffleButton.setEnabled(false);
        openButton.setFocusable(false);
        close.setFocusable(false);
        shuffleButton.setFocusable(false);

        widthLabel.setForeground(Color.WHITE);
        heightLabel.setForeground(Color.WHITE);

        app.add(close);
        app.add(xField);
        app.add(yField);
        app.add(shuffleButton);
        app.add(openButton);
        app.add(completeImage);
        app.add(board);
        app.add(widthLabel);
        app.add(heightLabel);
    }
}