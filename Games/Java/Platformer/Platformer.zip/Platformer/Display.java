import java.awt.Color;

import javax.swing.JFrame;

public class Display extends JFrame {
    public Display(Sprite[] entities) {
        setTitle("Platformer");
        getContentPane().setBackground(new Color(0f, .6f, 1f));
        setLayout(null);
        setSize(600, 500);
        setUndecorated(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        for (Sprite sprite : entities) add(sprite);
        setVisible(true);
    }
}
