import java.awt.Color;

public class DynamicSprite extends Sprite {
    private final double GRAVITY = .2;
    protected double y_velocity;
    protected boolean is_grounded; // Used more for jumps

    public DynamicSprite(int x, int y, int w, int h, Color c) {
        super(x, y, w, h, c);
        y_velocity = 0;
        is_grounded = false;
    }


    public void collide(Sprite s) { // Assume only floor
        if(is_colliding(s) && y_velocity > 0) {
            y = s.y - getHeight();
            y_velocity = 0;
            is_grounded = true;
        }
    }

    private boolean is_colliding(Sprite s) {
        return x + getWidth() > s.x && x < s.x + s.getWidth()
            && y + getHeight() > s.y && y + (7 * getHeight() / 8) < s.y + s.getHeight();
    }


    public void update(double dt) {
        setLocation((int) x, (int) y);
        y_velocity += GRAVITY * dt;
        y += y_velocity * dt;
    }
}