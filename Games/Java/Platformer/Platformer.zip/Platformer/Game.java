import java.awt.Color;

import javax.swing.JOptionPane;

public class Game {
    // https://codingtechroom.com/question/achieve-60-updates-per-second-java-delta-time

    private double dt;
    private DynamicSprite[] dynamic_sprites;
    private Sprite[] sprites;
    private final Color FLOOR_COLOR = new Color(.5f, .1f, .1f);

    private final double FPS = 1000000000.0 / 60.0;
    public Game() {
        Player player = new Player(500, 400, this);

        Sprite floor = new Sprite(-20, 490, 1000, 10, Color.GREEN);
        Sprite floor1 = new Sprite(0, 400, 100, 20, FLOOR_COLOR);
        Sprite floor2 = new Sprite(200, 300, 100, 10, FLOOR_COLOR);
        Sprite floor3 = new Sprite(550, 320, 30, 15, FLOOR_COLOR);
        Sprite floor4 = new Sprite(550, 240, 30, 5, FLOOR_COLOR);
        Sprite floor5 = new Sprite(550, 150, 30, 5, FLOOR_COLOR);
        Sprite floor6 = new Sprite(270, 150, 70, 5, FLOOR_COLOR);
        Sprite floor7 = new Sprite(100, 150, 130, 5, FLOOR_COLOR);
        Sprite goal = new Sprite(0, 0, 50, 50, Color.YELLOW);

        dynamic_sprites = new DynamicSprite[] {player};
        sprites = new Sprite[] {player, floor, floor1, floor2, floor3, floor4, floor5, floor6, floor7, goal};
        new Display(sprites);

        long last_time = System.nanoTime();
        while (true) {
            long now = System.nanoTime();
            dt = (now - last_time) / FPS;
            last_time = now;

            if(player.y > 1000) System.exit(0);
            if(player.x < 50 && player.y < 50) {
                JOptionPane.showMessageDialog(null, "YOU WIN!!!");
                System.exit(0);
            }
            for (DynamicSprite dynamic_sprite : dynamic_sprites) {
                dynamic_sprite.update(dt);
                for (Sprite sprite : sprites)
                    if(!sprite.equals(dynamic_sprite))
                        dynamic_sprite.collide(sprite);
            }
        }
    }
}