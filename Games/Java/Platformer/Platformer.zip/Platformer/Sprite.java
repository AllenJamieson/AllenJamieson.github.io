import java.awt.Color;

import javax.swing.JLabel;

public class Sprite extends JLabel {
    protected double x, y;

    public Sprite(int x, int y, int w, int h, Color c) {
        this.x = x;
        this.y = y;
        setBounds(x, y, w, h);
        setOpaque(true);
        setBackground(c);
    }
}

