import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Player extends DynamicSprite {

    private final short SPEED = 3;

    private double x_velocity;
    private boolean left_pressed, right_pressed, jump_pressed;

    public Player(int player_x, int player_y, Game game) {
        super(player_x, player_y, 20, 40, Color.BLACK);
        left_pressed = false;
        right_pressed = false;
        jump_pressed = false;
        x_velocity = 0;
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyChar() == 'a') left_pressed = true;
                if(e.getKeyChar() == 'd') right_pressed = true;
                if(e.getKeyChar() == ' ') jump_pressed = true;
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE) System.exit(0);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if(e.getKeyChar() == 'a') left_pressed = false;
                if(e.getKeyChar() == 'd') right_pressed = false;
                if(e.getKeyChar() == ' ') jump_pressed = false;
            }
        });
    }

    @Override
    public void update(double dt) {
        super.update(dt);
        x_velocity = 0;
        if(jump_pressed) jump();
        if(left_pressed) x_velocity = -SPEED;
        if(right_pressed) x_velocity = SPEED;
        if(left_pressed && right_pressed) x_velocity = 0;
        x += x_velocity * dt;
    }

    public void jump() {
        if(is_grounded) y_velocity = -6;
        is_grounded = false;
    }
}