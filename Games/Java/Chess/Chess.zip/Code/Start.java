import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Start {
    private static final short H = 550, W = 500;
    public static void main(String[] args) {
        JFrame app = new JFrame("Chess");
        JLabel lbl = new JLabel();
        Board board = new Board(lbl);
        lbl.setFont(new Font("SansSarif", Font.BOLD, 30));
        app.setLayout(new FlowLayout(FlowLayout.CENTER));
        app.add(lbl);
        app.add(board);
        app.setSize(W, H);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setResizable(false);
        app.setVisible(true);
    }
}