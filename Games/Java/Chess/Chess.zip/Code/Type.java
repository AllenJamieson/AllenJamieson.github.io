public enum Type {
    PAWN("black-pawn.png", "white-pawn.png"),
    ROOK("black-rook.png", "white-rook.png"), KNIGHT("black-knight.png", "white-knight.png"), BISHOP("black-bishop.png", "white-bishop.png"),
    KING("black-king.png", "white-king.png"), QUEEN("black-queen.png", "white-queen.png");
    
    private String black;
    private String white;
    private Type(String black, String white) { this.black = black; this.white = white; }
    public String getBlack() { return black; }
    public String getWhite() { return white; }
}