import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Piece extends ImageIcon {

// https://greenchess.net/info.php?item=downloads
    private final byte SIZE = 50;
    private final String PATH = "pieces-basic-png/";
    private Type type;
    private boolean isBlack;
    private boolean moved;
    private int move_time;

    public Piece(boolean isBlack, Type type) {
        this.isBlack = isBlack;
        this.type = type;
        moved = false;
        move_time = 0;
        setIcon();
    }

    public boolean isMove(byte x1, byte y1, byte x2, byte y2, Piece[][] current_board) {
        Piece first = current_board[y1][x1];
        Piece second = current_board[y2][x2];
        if(first.equals(second)) return false;
        if( // Castling
            second != null && first.getType().equals(Type.KING) && second.getType().equals(Type.ROOK) &&
            !first.moved && !second.moved && y1 == y2 && checkVH(x1, y1, x2, y2, current_board)
        ) {
            current_board[y1][x1] = null;
            if(x2 == 0) {
                current_board[y1][2] = first;
                current_board[y2][3] = second;
            }
            if(x2 == 7) {
                current_board[y1][6] = first;
                current_board[y2][5] = second;
            }
            System.out.println("Casling");
            return true;
        }
        if(second != null && first.isBlack() == second.isBlack()) return false;
        switch (type) {
            case PAWN: return pawn(x1, y1, x2, y2, first, second, current_board);
            case ROOK: return (x1 == x2 || y1 == y2) && checkVH(x1, y1, x2, y2, current_board);
            case KNIGHT:
                return (Math.abs(x1-x2) == 2 && Math.abs(y1-y2) == 1)
                    || (Math.abs(x1-x2) == 1 && Math.abs(y1-y2) == 2);
            case BISHOP: return (Math.abs(x1-x2) == Math.abs(y1-y2)) && checkD(x1, y1, x2, y2, current_board);
            case QUEEN:
                return ( (x1 == x2 || y1 == y2) && checkVH(x1, y1, x2, y2, current_board) )
                    || ( (Math.abs(x1-x2)) == Math.abs(y1-y2) && checkD(x1, y1, x2, y2, current_board) );
            case KING: return Math.abs(x1-x2) <= 1 && Math.abs(y1-y2) <= 1;
        } return false;
    }

    private boolean checkD(byte x1, byte y1, byte x2, byte y2, Piece[][] current_board) {
        while(x1 < x2 && y1 < y2) {
            Piece p = current_board[++y1][++x1];
            if(p != null && y1 != y2) return false;
        }
        while(x1 < x2 && y1 > y2) {
            Piece p = current_board[--y1][++x1];
            if(p != null && y1 != y2) return false;
        }
        while(x1 > x2 && y1 < y2) {
            Piece p = current_board[++y1][--x1];
            if(p != null && y1 != y2) return false;
        }
        while(x1 < x2 && y1 < y2) {
            Piece p = current_board[--y1][--x1];
            if(p != null && y1 != y2) return false;
        }
        return true;
    }

    private boolean checkVH(byte x1, byte y1, byte x2, byte y2, Piece[][] current_board) {
        while(y1 < y2) {
            Piece p = current_board[++y1][x1];
            if(p != null && y1 != y2) return false;
        }
        while(y1 > y2) {
            Piece p = current_board[--y1][x1];
            if(p != null && y1 != y2) return false;
        }
        while(x1 < x2) {
            Piece p = current_board[y1][++x1];
            if(p != null && x1 != x2) return false;
        }
        while(x1 > x2) {
            Piece p = current_board[y1][--x1];
            if(p != null && x1 != x2) return false;
        }
        return true;
    }

    private boolean pawn(byte x1, byte y1, byte x2, byte y2, Piece first, Piece second, Piece[][] current_board) {
        if(x1 == x2 && second != null) return false;
        if(y2 == position(7, 0) && moved1(y1, y2) && Math.abs(x1-x2) <= 1) { // Promotion Frame
            JFrame app = new JFrame("Promoting " + (isBlack() ? "Black" : "White"));
            for (Type t : Type.values()) {
                if(t.equals(Type.PAWN) || t.equals(Type.KING)) continue;
                JButton t_button = new JButton(t.toString());
                t_button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        first.type = t;
                        setIcon();
                        app.dispose();
                    }
                });
                app.add(t_button);// TODO Set this as the only focus until done?
            }
            app.setSize(30, 500);
            app.setLayout(new GridLayout(Type.values().length, 1));
            app.setVisible(true);
            System.out.println("Promotion");
        }
        if(x1 == x2 && moved1(y1, y2)) return true;
        if(
            !first.moved && x1 == x2 && y1 + position(2, -2) == y2 &&
            current_board[y1 + position(1, -1)][x1] == null
        ) return true;
        if(second != null && Math.abs(x1 - x2) == 1 && moved1(y1, y2)) return true;
        if( // En Pessant
            moved1(x1, x2) && y2 == position(5, 2) && second == null &&
            current_board[y1][x2].getType().equals(Type.PAWN) && current_board[y1][x2].enpesentable()
        ) { current_board[y1][x2] = null; System.out.println("En Passant"); return true; }
        return false;
    }

    private void setIcon() {
        String path = PATH + (isBlack() ? type.getBlack() : type.getWhite());
        try {
            BufferedImage image = ImageIO.read(getClass().getResource(path));
            BufferedImage scaled = new BufferedImage(SIZE, SIZE, BufferedImage.TYPE_INT_ARGB);
            scaled.getGraphics().drawImage(image, 0, 0, SIZE, SIZE, null);
            setImage(scaled);
        } catch (IOException e) { System.out.println("Image not Found\n" + path); }
    }

    private boolean moved1(byte a, byte b) { return Math.abs(a - b) == 1; }
    private byte position(int black, int white) { return isBlack() ? (byte)black : (byte)white; }
    public void moved() { move_time = 0; moved = true; }
    public void nextMove() { move_time++; }
    public boolean enpesentable() { return move_time == 1; }
    public Type getType() { return type; }
    public boolean isBlack() { return isBlack; }
}