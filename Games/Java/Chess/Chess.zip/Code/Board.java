import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Board extends JPanel {
    private byte selected_x, selected_y;
    private boolean blacks_turn;
    private JLabel lbl;

    private Piece[][] starting_board = {
        {
            new Piece(true, Type.ROOK), new Piece(true, Type.KNIGHT), new Piece(true, Type.BISHOP),
            new Piece(true, Type.QUEEN), new Piece(true, Type.KING), 
            new Piece(true, Type.BISHOP), new Piece(true, Type.KNIGHT), new Piece(true, Type.ROOK)
        },
        {
            new Piece(true, Type.PAWN), new Piece(true, Type.PAWN),
            new Piece(true, Type.PAWN), new Piece(true, Type.PAWN),
            new Piece(true, Type.PAWN), new Piece(true, Type.PAWN),
            new Piece(true, Type.PAWN), new Piece(true, Type.PAWN)
        },
        { null, null, null, null, null, null, null, null },
        { null, null, null, null, null, null, null, null },
        { null, null, null, null, null, null, null, null },
        { null, null, null, null, null, null, null, null },
        {
            new Piece(false, Type.PAWN), new Piece(false, Type.PAWN),
            new Piece(false, Type.PAWN), new Piece(false, Type.PAWN),
            new Piece(false, Type.PAWN), new Piece(false, Type.PAWN),
            new Piece(false, Type.PAWN), new Piece(false, Type.PAWN)
        },
        {
            new Piece(false, Type.ROOK), new Piece(false, Type.KNIGHT), new Piece(false, Type.BISHOP),
            new Piece(false, Type.QUEEN), new Piece(false, Type.KING),
            new Piece(false, Type.BISHOP), new Piece(false, Type.KNIGHT), new Piece(false, Type.ROOK)
        }
    };

    private Piece[][] game;

    public Board(JLabel lbl) {
        this.lbl = lbl;
        game = new Piece[8][8];
        setLayout(new GridLayout(8, 8, -1, -1));
        restart();
        redraw();
        lbl.setText("Press on the board to start");
    }

    public void makeMove(byte x, byte y) {
        lbl.setText((isBlacksTurn() ? "Blacks" : "Whites") + " Turn"); // Only useful at the start of the game
        if(notSelected()) {
            if(game[y][x] != null) {
                selected_x = x; selected_y = y;
            }
        } else {
            Piece temp = game[selected_y][selected_x];
            if(temp.isMove(selected_x, selected_y, x, y, game)) {
                if(game[y][x] != null && game[y][x].getType().equals(Type.KING)) restart();
                else {
                    game[y][x] = game[selected_y][selected_x];
                    game[selected_y][selected_x] = null;
                    temp.moved();
                    blacks_turn = !blacks_turn;
                    lbl.setText((isBlacksTurn() ? "Blacks" : "Whites") + " Turn");
                }
            }
            selected_x = -1; // Reset selection
            redraw();
        }
    }

    private void redraw() {
        removeAll();
        for(byte v = 0; v < game.length; v++) {
            for(byte h = 0; h < game[0].length; h++) {
                Piece p = game[v][h];
                if(p != null) p.nextMove();
                add(new GridSquare(p, h, v, this));
            }
        }
        revalidate();
    }

    private void restart() {
        lbl.setText((isBlacksTurn() ? "Black" : "White") + " Wins");
        blacks_turn = false;
        for(byte v = 0; v < game.length; v++)
            for(byte h = 0; h < game[0].length; h++)
                game[v][h] = starting_board[v][h];
    }

    public boolean notSelected() { return selected_x == -1; }
    public boolean isBlacksTurn() { return blacks_turn; }
}