import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.border.LineBorder;

public class GridSquare extends JLabel {
    private Piece piece;
    private byte x, y;

    public GridSquare(Piece piece, byte x, byte y, Board board) {
        this.piece = piece;
        this.x = x;
        this.y = y;
        setIcon(piece);
        setHorizontalAlignment(CENTER);
        setOpaque(true);
        setBackground(isLightSquare() ? Color.WHITE : Color.GRAY);
        setBorder(new LineBorder(Color.BLACK));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(board.notSelected() && piece != null && board.isBlacksTurn() != piece.isBlack()) return;
                if(piece != null) setBackground(Color.DARK_GRAY);
                board.makeMove(x, y);
            }
        });
    }

    private boolean isLightSquare() { return (x % 2 == 0 && y % 2 == 0) || (x % 2 == 1 && y % 2 == 1); }
    public Piece getPiece() { return piece; }
}