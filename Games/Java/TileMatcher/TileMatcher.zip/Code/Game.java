import java.util.ArrayList;

public class Game {
    private final short HEIGHT, WIDTH;

    private int score;
    private Token[][] board;

    public Game(short h, short w) { score = 0; HEIGHT = h; WIDTH = w; }

    public boolean possibleMoveSearch() {
        for (short v = 2; v < HEIGHT+2; v++) { // Starts with the center and checks 12 possible moves
            for (short h = 2; h < WIDTH+2; h++) {
                Token current = board[v][h],
                    one = board[v-1][h-1], two = board[v-1][h], three = board[v-1][h+1],
                    four = board[v][h-1], five = board[v][h+1],
                    six = board[v+1][h-1], seven = board[v+1][h], eight = board[v+1][h+1];
                if(current.equals(two) && current.equals(six)) return true;
                if(current.equals(two) && current.equals(eight)) return true;
                if(current.equals(seven) && current.equals(one)) return true;
                if(current.equals(seven) && current.equals(three)) return true;
                if(current.equals(four) && current.equals(three)) return true;
                if(current.equals(four) && current.equals(eight)) return true;
                if(current.equals(five) && current.equals(one)) return true;
                if(current.equals(five) && current.equals(six)) return true;
                if(current.equals(one) && current.equals(three)) return true;
                if(current.equals(one) && current.equals(six)) return true;
                if(current.equals(three) && current.equals(eight)) return true;
                if(current.equals(six) && current.equals(eight)) return true;
            }
        }
        return false;
    }

    public ArrayList<Integer> searchPoppable() {
        int position = 0;
        ArrayList<Integer> poppable = new ArrayList<>();
        for (short v = 2; v < HEIGHT+2; v++) {
            for (short h = 2; h < WIDTH+2; h++) {
                Token current = board[v][h];
                if ((current.equals(board[v-1][h]) && current.equals(board[v-2][h])) ||
                    (current.equals(board[v-1][h]) && current.equals(board[v+1][h])) ||
                    (current.equals(board[v+1][h]) && current.equals(board[v+2][h])) ||
                    (current.equals(board[v][h-1]) && current.equals(board[v][h-2])) ||
                    (current.equals(board[v][h-1]) && current.equals(board[v][h+1])) ||
                    (current.equals(board[v][h+1]) && current.equals(board[v][h+2]))
                   ) { poppable.add(position); score++; }
                position++;
            }
        }
        return poppable;
    }

    public void popCandy() {
        ArrayList<Integer> poppable = searchPoppable();
        for (Integer pop_position : poppable) board[pop_position/WIDTH+2][pop_position%WIDTH+2] = null;
    }

    public boolean isMove(Token a, Token b, short x1, short y1, short x2, short y2) {
        if(a.equals(b)) return false;
        short xdif = (short) (x1-x2), ydif = (short) (y1-y2);
        if((Math.abs(xdif) ^ Math.abs(ydif)) != 1) return false;
        
        if(xdif == 0) {
        }
        if(ydif == 0) {
        }
        System.out.println(xdif);
        System.out.println(ydif);

        System.out.println("Move");
        return true; // TODO
    }

    public int getScore() { return score; }
    public Token[][] getBoard() { return board; }
    public void setBoard(Token[][] board) { this.board = board; }
}