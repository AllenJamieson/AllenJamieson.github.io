import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

// https://jinhzaki.itch.io/minerals-pack-free-32x32
public class Token extends JLabel {
    private final short SIZE = 32;
    private String img_path;
    private Board board;

    public Token(String img_path, Board board) {
        this.img_path = img_path;
        this.board = board;
        setSize(SIZE, SIZE);
        setIcon(new ImageIcon(getClass().getResource("Tokens/" + img_path)));
        Token t = this;
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) { board.select(t); }

            @Override
            public void mouseReleased(MouseEvent e) { board.deselect(); }

            @Override
            public void mouseEntered(MouseEvent e) { board.move(t); }
        });
    }

    public Token copy() { return new Token(img_path, board); }
    public short getSIZE() { return SIZE; }
    @Override
    public boolean equals(Object obj) { return obj != null && img_path.equals(((Token) obj).img_path); }
    @Override
    public String toString() { return img_path; }
}