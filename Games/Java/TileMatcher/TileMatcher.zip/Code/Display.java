import javax.swing.JFrame;
import javax.swing.JLabel;

public class Display {
    private JFrame app;
    private JLabel score;
    private Board board;

    public Display() {
        app = new JFrame();
        app.setLayout(null);
        score = new JLabel();
        board = new Board(score);
        score.setBounds(5, 5, 500, 30);
        board.setBounds(5, 50, 500, 500);
        app.add(board);
        app.add(score);
        app.setSize(500, 500);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    } 
}
