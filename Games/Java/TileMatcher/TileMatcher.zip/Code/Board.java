import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

// TODO Animation works?
public class Board extends JPanel {
    private final short HEIGHT = 7, WIDTH = 7, PADDING = 0, SIZE;
    private final Token[] TOKENS = {
        new Token("Copper gem.png", this), new Token("Diamond gem.png", this),
        new Token("Emeral Gem.png", this), new Token("Gold Gem.png", this),
        new Token("Iron Gem.png", this), new Token("Purple Gem.png", this) };

    private Token[][] board;
    private Random rand;
    private Token selectedToken;
    private Game game;
    private JLabel score;
    private short count;

    public Board(JLabel score) {
        count = 0;
        SIZE = TOKENS[0].getSIZE();
        this.score = score;
        setLayout(null);
        rand = new Random();
        game = new Game(HEIGHT, WIDTH);
        board = new Token[HEIGHT+4][WIDTH+4]; // Boarder 2 thick of null to make search algoritms are easier
        

        shuffle();
        game.popCandy();
        board = game.getBoard();
        updateBoard();
        gravity();

        // TODO shuffle, pop, gravity, check
    }
    
    private void shuffle() {
        for (short v = 0; v < HEIGHT; v++)
            for (short h = 0; h < WIDTH; h++)
                board[v+2][h+2] = TOKENS[rand.nextInt(TOKENS.length)].copy();
        game.setBoard(board);
        updateBoard();
    }

    public void select(Token t) { selectedToken = t; }
    public void deselect() { selectedToken = null; }
    public void move(Token t) {
        if(selectedToken == null || count != WIDTH) return;
        short xFirst = (short) (selectedToken.getX()/(SIZE+PADDING)),
            xLast = (short) (t.getX()/(SIZE+PADDING)),
            yFirst = (short) (selectedToken.getY()/(SIZE+PADDING)),
            yLast = (short) (t.getY()/(SIZE+PADDING));
        if(!game.isMove(selectedToken, t, xFirst, yFirst, xLast, yLast)) return;
        board[yFirst+2][xFirst+2] = t;
        board[yLast+2][xLast+2] = selectedToken;
        positionToken(xFirst, yFirst);
        positionToken(xLast, yLast);


        game.popCandy();
        board = game.getBoard();
        gravity();
        // TODO The check is using game.searchPoppable
        selectedToken = null;
    }

    private void updateBoard() {
        removeAll();
        repaint();
        for (short v = 0; v < HEIGHT; v++) {
            for (short h = 0; h < WIDTH; h++) {
                if(board[v+2][h+2] == null) continue;
                positionToken(h, v);
                add(board[v+2][h+2]);
            }
        }
    }

    private void gravity() {
        count = 0;
        for (short h = 0; h < WIDTH; h++) {
            short a = h; // TODO Replace with a while loop?
            Timer timer = new Timer(250, null);
            timer.addActionListener(new ActionListener() {
                short h = a;
                @Override
                public void actionPerformed(ActionEvent e) {
                    boolean cont = false;
                    for (short v = 0; v < HEIGHT; v++) {
                        if(board[v+2][h+2] == null) {
                            cont = true;
                            if(v == 0)
                                board[v+2][h+2] = TOKENS[rand.nextInt(TOKENS.length)].copy();
                            else {
                                board[v+2][h+2] = board[v+1][h+2];
                                board[v+1][h+2] = null;
                            }
                        }
                    }
                    updateBoard();
                    if(!cont) {
                        count++;
                        timer.stop();
                        game.setBoard(board);
                        score.setText("Score: " + game.getScore());
                    }
                }
            });
            timer.start();
        }
    }

// TODO UPDATE

    private void positionToken(int x, int y) { board[y+2][x+2].setLocation(SIZE*x + PADDING*x, SIZE*y + PADDING*y); }
}