import java.util.ArrayList;

public class Game {
    private final short HEIGHT, WIDTH;

    private int score;
    private Token[][] board;

    public Game(short h, short w) { score = 0; HEIGHT = h; WIDTH = w; }

    public boolean possibleMoveSearch() {
        for (short v = 2; v < HEIGHT+2; v++) { // Starts with the center and checks 12 possible moves
            for (short h = 2; h < WIDTH+2; h++) {
                Token current = board[v][h],
                    one = board[v-1][h-1], two = board[v-1][h], three = board[v-1][h+1],
                    four = board[v][h-1], five = board[v][h+1],
                    six = board[v+1][h-1], seven = board[v+1][h], eight = board[v+1][h+1];
                if(current.equals(two) && current.equals(six)) return true;
                if(current.equals(two) && current.equals(eight)) return true;
                if(current.equals(seven) && current.equals(one)) return true;
                if(current.equals(seven) && current.equals(three)) return true;
                if(current.equals(four) && current.equals(three)) return true;
                if(current.equals(four) && current.equals(eight)) return true;
                if(current.equals(five) && current.equals(one)) return true;
                if(current.equals(five) && current.equals(six)) return true;
                if(current.equals(one) && current.equals(three)) return true;
                if(current.equals(one) && current.equals(six)) return true;
                if(current.equals(three) && current.equals(eight)) return true;
                if(current.equals(six) && current.equals(eight)) return true;
            }
        }
        return false;
    }

    public ArrayList<Integer> searchPoppable() {
        int position = 0;
        ArrayList<Integer> poppable = new ArrayList<>();
        for (short v = 2; v < HEIGHT+2; v++) {
            for (short h = 2; h < WIDTH+2; h++) {
                Token current = board[v][h];
                if ((current.equals(board[v-1][h]) && current.equals(board[v-2][h])) ||
                    (current.equals(board[v-1][h]) && current.equals(board[v+1][h])) ||
                    (current.equals(board[v+1][h]) && current.equals(board[v+2][h])) ||
                    (current.equals(board[v][h-1]) && current.equals(board[v][h-2])) ||
                    (current.equals(board[v][h-1]) && current.equals(board[v][h+1])) ||
                    (current.equals(board[v][h+1]) && current.equals(board[v][h+2]))
                   ) { poppable.add(position); score++; }
                position++;
            }
        }
        return poppable;
    }

    public boolean popCandy() {
        ArrayList<Integer> poppable = searchPoppable();
        for (Integer pop_position : poppable) board[pop_position/WIDTH+2][pop_position%WIDTH+2] = null;
        return !poppable.isEmpty();
    }

    public boolean isMove(int x1, int y1, int x2, int y2) {
        Token a = board[y1][x1];
        Token b = board[y2][x2];
        short xdif = (short) (x1-x2), ydif = (short) (y1-y2);

        if(a.equals(b)) return false;
        if((Math.abs(xdif) ^ Math.abs(ydif)) != 1) return false;
        if(ydif != 0) {
            if(a.equals(board[y2][x2-1]) && a.equals(board[y2][x2-2])) return true;
            if(a.equals(board[y2][x2-1]) && a.equals(board[y2][x2+1])) return true;
            if(a.equals(board[y2][x2+1]) && a.equals(board[y2][x2+2])) return true;

            if(b.equals(board[y1][x1-1]) && b.equals(board[y1][x2-2])) return true;
            if(b.equals(board[y1][x1-1]) && b.equals(board[y1][x2+1])) return true;
            if(b.equals(board[y1][x1+1]) && b.equals(board[y1][x2+2])) return true;

            if(ydif == 1  && a.equals(board[y2-1][x2])&& a.equals(board[y2-2][x2])) return true;
            if(ydif == -1 && a.equals(board[y2+1][x2])&& a.equals(board[y2+2][x2])) return true;
            if(ydif == -1 && b.equals(board[y1-1][x1])&& b.equals(board[y1-2][x1])) return true;
            if(ydif == 1  && b.equals(board[y1+1][x1])&& b.equals(board[y1+2][x1])) return true;
        }
        if(xdif != 0) {
            if(a.equals(board[y2-1][x2]) && a.equals(board[y2-2][x2])) return true;
            if(a.equals(board[y2-1][x2]) && a.equals(board[y2+1][x2])) return true;
            if(a.equals(board[y2+1][x2]) && a.equals(board[y2+2][x2])) return true;

            if(b.equals(board[y1-1][x1]) && b.equals(board[y1-2][x1])) return true;
            if(b.equals(board[y1-1][x1]) && b.equals(board[y1+1][x1])) return true;
            if(b.equals(board[y1+1][x1]) && b.equals(board[y1+2][x1])) return true;

            if(xdif == 1  && a.equals(board[y2][x2-1])&& a.equals(board[y2][x2-2])) return true;
            if(xdif == -1 && a.equals(board[y2][x2+1])&& a.equals(board[y2][x2+2])) return true;
            if(xdif == -1 && b.equals(board[y1][x1-1])&& b.equals(board[y1][x1-2])) return true;
            if(xdif == 1  && b.equals(board[y1][x1+1])&& b.equals(board[y1][x1+2])) return true;
        }
        return false;
    }

    public int getScore() { return score; }
    public Token[][] getBoard() { return board; }
    public void setBoard(Token[][] board) { this.board = board; }
}