import javax.swing.JFrame;
import javax.swing.JLabel;

public class Display {
    private JFrame app;
    private JLabel score;
    private Board board;

    public Display() {
        app = new JFrame("Tile Matcher");
        app.setLayout(null);
        score = new JLabel("Score: 0");
        score.setBounds(5, 5, 500, 30);
        app.add(score);

        board = new Board(score);
        board.setLocation(5, 50);
        app.add(board);
        app.setSize(board.getWidth() + 10, board.getHeight() + 100);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setVisible(true);
    } 
}