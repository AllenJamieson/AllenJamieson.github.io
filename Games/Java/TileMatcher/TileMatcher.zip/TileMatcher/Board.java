import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Board extends JPanel {
    private final short HEIGHT = 10, WIDTH = 10, SIZE;
    private final Token[] TOKENS = {
        new Token("Copper gem.png", this), new Token("Diamond gem.png", this),
        new Token("Emeral Gem.png", this), new Token("Gold Gem.png", this),
        new Token("Iron Gem.png", this), new Token("Purple Gem.png", this) };

    private Token[][] board;
    private Random rand;
    private Token selectedToken;
    private Game game;
    private JLabel score;
    private short count;
    private boolean reupdate;

    public Board(JLabel score) {
        count = 0;
        reupdate = true;
        SIZE = TOKENS[0].getSIZE();
        this.score = score;
        setLayout(null);
        rand = new Random();
        game = new Game(HEIGHT, WIDTH);
        board = new Token[HEIGHT+4][WIDTH+4];

        setSize(1000, 1000);
        setSize(WIDTH * TOKENS[0].getWidth(), HEIGHT * TOKENS[0].getHeight());
        gravity();
    }

    private void update() {
        game.setBoard(board);
        reupdate = game.popCandy();
        board = game.getBoard();
        gravity();
    }

    public void select(Token t) { selectedToken = t; }
    public void deselect() { selectedToken = null; }
    public void move(Token t) {
        if(selectedToken == null || count != WIDTH) return;
        int xFirst = selectedToken.getX()/SIZE,
            xLast = t.getX()/SIZE,
            yFirst = selectedToken.getY()/SIZE,
            yLast = t.getY()/SIZE;
        if(!game.isMove(xFirst+2, yFirst+2, xLast+2, yLast+2)) return;
        board[yFirst+2][xFirst+2] = t;
        board[yLast+2][xLast+2] = selectedToken;
        positionToken(xFirst, yFirst);
        positionToken(xLast, yLast);
        update();
        selectedToken = null;
    }

    private void updateBoard() {
        removeAll();
        repaint();
        for (short v = 0; v < HEIGHT; v++) {
            for (short h = 0; h < WIDTH; h++) {
                if(board[v+2][h+2] == null) continue;
                positionToken(h, v);
                add(board[v+2][h+2]);
            }
        }
    }

    private void gravity() {
        count = 0;
        for (short h = 0; h < WIDTH; h++) {
            short a = h;
            Timer timer = new Timer(100, null);
            timer.addActionListener(new ActionListener() {
                short h = a;
                @Override
                public void actionPerformed(ActionEvent e) {
                    boolean cont = false;
                    for (short v = HEIGHT - 1; v >= 0; v--) {
                        if(board[v+2][h+2] == null) {
                            cont = true;
                            if(v == 0)
                                board[v+2][h+2] = TOKENS[rand.nextInt(TOKENS.length)].copy();
                            else {
                                board[v+2][h+2] = board[v+1][h+2];
                                board[v+1][h+2] = null;
                            }
                        }
                    }
                    updateBoard();
                    if(!cont) {
                        count++;
                        timer.stop();
                        score.setText("Score: " + game.getScore());
                        if(count == WIDTH) {
                            if(reupdate) update();
                            else if(!game.possibleMoveSearch()) JOptionPane.showMessageDialog(null, "No More Moves\nThe Score is " + score);
                        }
                    }
                }
            });
            timer.setInitialDelay(250);
            timer.start();
        }
    }

    private void positionToken(int x, int y) { board[y+2][x+2].setLocation(SIZE * x, SIZE * y); }
}