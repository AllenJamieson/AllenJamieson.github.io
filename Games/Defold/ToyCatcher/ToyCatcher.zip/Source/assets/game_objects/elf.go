components {
  id: "elf"
  component: "/assets/scripts/elf.script"
}
embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"elf_idle\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/main.atlas\"\n"
  "}\n"
  ""
  position {
    y: -23.0
  }
  scale {
    x: 0.25
    y: 0.25
  }
}
embedded_components {
  id: "coal"
  type: "factory"
  data: "prototype: \"/assets/game_objects/toy/coal.go\"\n"
  ""
}
embedded_components {
  id: "kisses"
  type: "factory"
  data: "prototype: \"/assets/game_objects/toy/kisses.go\"\n"
  ""
}
embedded_components {
  id: "candy_cane"
  type: "factory"
  data: "prototype: \"/assets/game_objects/toy/candy_cane.go\"\n"
  ""
}
embedded_components {
  id: "toy_train"
  type: "factory"
  data: "prototype: \"/assets/game_objects/toy/toy_train.go\"\n"
  ""
}
embedded_components {
  id: "present"
  type: "factory"
  data: "prototype: \"/assets/game_objects/toy/present.go\"\n"
  ""
}
embedded_components {
  id: "nutcracker"
  type: "factory"
  data: "prototype: \"/assets/game_objects/toy/nutcracker.go\"\n"
  ""
}
embedded_components {
  id: "timer"
  type: "factory"
  data: "prototype: \"/assets/game_objects/toy/timer.go\"\n"
  ""
}
embedded_components {
  id: "merry"
  type: "sound"
  data: "sound: \"/assets/sound/merry elf.ogg\"\n"
  "speed: 1.5\n"
  ""
}
