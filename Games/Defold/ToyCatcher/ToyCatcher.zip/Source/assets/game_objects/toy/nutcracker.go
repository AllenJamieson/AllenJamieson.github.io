components {
  id: "toy"
  component: "/assets/scripts/toy.script"
}
embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"nutcracker\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/main.atlas\"\n"
  "}\n"
  ""
  position {
    x: 3.0
    y: 13.0
  }
  rotation {
    z: -0.5
    w: 0.8660254
  }
  scale {
    x: 0.0625
    y: 0.0625
  }
}
embedded_components {
  id: "collisionobject"
  type: "collisionobject"
  data: "type: COLLISION_OBJECT_TYPE_DYNAMIC\n"
  "mass: 1.0\n"
  "friction: 0.1\n"
  "restitution: 0.5\n"
  "group: \"toy\"\n"
  "mask: \"santa\"\n"
  "mask: \"bounds\"\n"
  "embedded_collision_shape {\n"
  "  shapes {\n"
  "    shape_type: TYPE_BOX\n"
  "    position {\n"
  "      x: 2.0\n"
  "      y: 12.0\n"
  "    }\n"
  "    rotation {\n"
  "      z: -0.5\n"
  "      w: 0.8660254\n"
  "    }\n"
  "    index: 0\n"
  "    count: 3\n"
  "    id: \"box\"\n"
  "  }\n"
  "  data: 10.0\n"
  "  data: 25.0\n"
  "  data: 10.0\n"
  "}\n"
  ""
}
