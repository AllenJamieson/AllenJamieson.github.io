components {
  id: "toy"
  component: "/assets/scripts/toy.script"
}
embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"candy_cane\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/main.atlas\"\n"
  "}\n"
  ""
  position {
    x: 5.0
    y: 15.0
  }
  rotation {
    z: -0.25881904
    w: 0.9659258
  }
  scale {
    x: 0.25
    y: 0.25
  }
}
embedded_components {
  id: "collisionobject"
  type: "collisionobject"
  data: "type: COLLISION_OBJECT_TYPE_DYNAMIC\n"
  "mass: 1.0\n"
  "friction: 0.1\n"
  "restitution: 0.5\n"
  "group: \"toy\"\n"
  "mask: \"santa\"\n"
  "mask: \"bounds\"\n"
  "embedded_collision_shape {\n"
  "  shapes {\n"
  "    shape_type: TYPE_SPHERE\n"
  "    position {\n"
  "      x: 16.0\n"
  "      y: 27.0\n"
  "    }\n"
  "    rotation {\n"
  "    }\n"
  "    index: 0\n"
  "    count: 1\n"
  "    id: \"circle\"\n"
  "  }\n"
  "  shapes {\n"
  "    shape_type: TYPE_BOX\n"
  "    position {\n"
  "      y: 6.0\n"
  "    }\n"
  "    rotation {\n"
  "      z: -0.5591929\n"
  "      w: 0.82903755\n"
  "    }\n"
  "    index: 1\n"
  "    count: 3\n"
  "    id: \"base\"\n"
  "  }\n"
  "  data: 15.0\n"
  "  data: 2.5\n"
  "  data: 25.0\n"
  "  data: 10.0\n"
  "}\n"
  ""
}
