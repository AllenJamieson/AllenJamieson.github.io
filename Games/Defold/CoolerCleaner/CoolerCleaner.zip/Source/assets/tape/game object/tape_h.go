components {
  id: "tape"
  component: "/assets/tape/tape.script"
}
embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"tape1\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/assets/tape/tape.atlas\"\n"
  "}\n"
  ""
  scale {
    x: 1.5
    y: 0.25
  }
}
embedded_components {
  id: "collison"
  type: "collisionobject"
  data: "type: COLLISION_OBJECT_TYPE_TRIGGER\n"
  "mass: 0.0\n"
  "friction: 0.1\n"
  "restitution: 0.5\n"
  "group: \"tape\"\n"
  "mask: \"player\"\n"
  "embedded_collision_shape {\n"
  "  shapes {\n"
  "    shape_type: TYPE_BOX\n"
  "    position {\n"
  "    }\n"
  "    rotation {\n"
  "    }\n"
  "    index: 0\n"
  "    count: 3\n"
  "    id: \"box\"\n"
  "  }\n"
  "  data: 48.0\n"
  "  data: 8.0\n"
  "  data: 0.5\n"
  "}\n"
  ""
}
