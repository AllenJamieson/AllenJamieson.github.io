components {
  id: "cooler"
  component: "/assets/cooler/cooler.script"
}
components {
  id: "tape_cooler"
  component: "/assets/cooler/tape_cooler.script"
}
embedded_components {
  id: "model"
  type: "model"
  data: "mesh: \"/assets/cooler/cooler.glb\"\n"
  "name: \"{{NAME}}\"\n"
  "materials {\n"
  "  name: \"default\"\n"
  "  material: \"/builtins/materials/model.material\"\n"
  "  textures {\n"
  "    sampler: \"tex0\"\n"
  "    texture: \"/assets/cooler/cooler texture.png\"\n"
  "  }\n"
  "}\n"
  ""
  position {
    y: -0.5
  }
}
embedded_components {
  id: "tape_v"
  type: "factory"
  data: "prototype: \"/assets/tape/game object/tape_v.go\"\n"
  ""
}
embedded_components {
  id: "tape_h"
  type: "factory"
  data: "prototype: \"/assets/tape/game object/tape_h.go\"\n"
  ""
}
embedded_components {
  id: "tape_v1"
  type: "factory"
  data: "prototype: \"/assets/tape/game object/tape_v1.go\"\n"
  ""
}
embedded_components {
  id: "tape_h1"
  type: "factory"
  data: "prototype: \"/assets/tape/game object/tape_h1.go\"\n"
  ""
}
embedded_components {
  id: "code"
  type: "sprite"
  data: "default_animation: \"barcode_qrcode\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/assets/tape/tape.atlas\"\n"
  "}\n"
  ""
  position {
    z: 0.501
  }
  scale {
    x: 0.001
    y: 0.001
  }
}
embedded_components {
  id: "remove_tape"
  type: "sound"
  data: "sound: \"/assets/cooler/remove_tape.ogg\"\n"
  "gain: 10.0\n"
  "speed: 1.5\n"
  ""
}
